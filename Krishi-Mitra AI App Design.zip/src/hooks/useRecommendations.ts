import { useState, useEffect } from 'react'
import { recommendationAPI } from '../lib/api'
import type { CropRecommendation } from '../lib/supabase'
import { useAuth } from './useAuth'

export function useRecommendations() {
  const { user } = useAuth()
  const [recommendations, setRecommendations] = useState<CropRecommendation[]>([])
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    if (user) {
      loadRecommendations()
    }
  }, [user])

  const loadRecommendations = async () => {
    if (!user) return
    
    try {
      setLoading(true)
      const data = await recommendationAPI.getUserRecommendations(user.id)
      setRecommendations(data)
      setError(null)
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to load recommendations')
    } finally {
      setLoading(false)
    }
  }

  const generateRecommendations = async (inputData: any) => {
    if (!user) throw new Error('User not authenticated')

    try {
      setLoading(true)
      setError(null)

      // Get AI recommendations
      const aiRecommendations = await recommendationAPI.getCropRecommendations(inputData)
      
      // Save to database
      const recommendationData = {
        user_id: user.id,
        farm_id: inputData.farmId,
        season: inputData.season || 'current',
        recommendations: aiRecommendations,
        input_data: inputData
      }

      const savedRecommendation = await recommendationAPI.saveRecommendation(recommendationData)
      
      // Update local state
      setRecommendations(prev => [savedRecommendation, ...prev])
      
      return aiRecommendations
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to generate recommendations')
      throw err
    } finally {
      setLoading(false)
    }
  }

  return {
    recommendations,
    loading,
    error,
    generateRecommendations,
    refreshRecommendations: loadRecommendations
  }
}