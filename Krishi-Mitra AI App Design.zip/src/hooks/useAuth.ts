import { useState, useEffect, useContext, createContext } from 'react'
import { User } from '@supabase/supabase-js'
import { authAPI, userAPI } from '../lib/api'
import type { User as AppUser } from '../lib/supabase'

interface AuthContextType {
  user: User | null
  profile: AppUser | null
  loading: boolean
  signUp: (email: string, password: string, userData: { name: string; phone?: string; location: string }) => Promise<any>
  signIn: (email: string, password: string) => Promise<any>
  signOut: () => Promise<void>
  updateProfile: (updates: Partial<AppUser>) => Promise<void>
}

const AuthContext = createContext<AuthContextType | undefined>(undefined)

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null)
  const [profile, setProfile] = useState<AppUser | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    // Get initial user
    authAPI.getCurrentUser().then((user) => {
      setUser(user)
      if (user) {
        loadUserProfile(user.id)
      } else {
        setLoading(false)
      }
    })

    // Listen for auth changes
    const { data: { subscription } } = authAPI.onAuthStateChange(async (event, session) => {
      setUser(session?.user || null)
      
      if (session?.user) {
        await loadUserProfile(session.user.id)
      } else {
        setProfile(null)
      }
      
      setLoading(false)
    })

    return () => subscription.unsubscribe()
  }, [])

  const loadUserProfile = async (userId: string) => {
    try {
      const profileData = await userAPI.getProfile(userId)
      setProfile(profileData)
    } catch (error) {
      console.error('Error loading user profile:', error)
    } finally {
      setLoading(false)
    }
  }

  const signUp = async (email: string, password: string, userData: { name: string; phone?: string; location: string }) => {
    const { data, error } = await authAPI.signUp(email, password, userData)
    if (error) throw error
    return data
  }

  const signIn = async (email: string, password: string) => {
    const { data, error } = await authAPI.signIn(email, password)
    if (error) throw error
    return data
  }

  const signOut = async () => {
    const { error } = await authAPI.signOut()
    if (error) throw error
    setUser(null)
    setProfile(null)
  }

  const updateProfile = async (updates: Partial<AppUser>) => {
    if (!user) throw new Error('No user logged in')
    
    const updatedProfile = await userAPI.updateProfile(user.id, updates)
    setProfile(updatedProfile)
  }

  return (
    <AuthContext.Provider value={{
      user,
      profile,
      loading,
      signUp,
      signIn,
      signOut,
      updateProfile
    }}>
      {children}
    </AuthContext.Provider>
  )
}

export function useAuth() {
  const context = useContext(AuthContext)
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider')
  }
  return context
}