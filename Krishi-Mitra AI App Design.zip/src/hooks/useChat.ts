import { useState, useEffect } from 'react'
import { chatAPI } from '../lib/api'
import type { ChatMessage } from '../lib/supabase'
import { useAuth } from './useAuth'

export function useChat() {
  const { user } = useAuth()
  const [messages, setMessages] = useState<ChatMessage[]>([])
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    if (user) {
      loadChatHistory()
      
      // Subscribe to new messages
      const subscription = chatAPI.subscribeToMessages(user.id, (newMessage) => {
        setMessages(prev => [...prev, newMessage])
      })

      return () => {
        subscription.unsubscribe()
      }
    }
  }, [user])

  const loadChatHistory = async () => {
    if (!user) return
    
    try {
      setLoading(true)
      const history = await chatAPI.getChatHistory(user.id)
      setMessages(history)
      setError(null)
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to load chat history')
    } finally {
      setLoading(false)
    }
  }

  const sendMessage = async (message: string, messageType: 'text' | 'image' | 'voice' = 'text', imageUrl?: string) => {
    if (!user) throw new Error('User not authenticated')

    try {
      setError(null)
      
      // Add user message to UI immediately
      const userMessage = {
        id: `temp-${Date.now()}`,
        user_id: user.id,
        message,
        response: '',
        message_type: messageType,
        image_url: imageUrl,
        created_at: new Date().toISOString()
      }
      setMessages(prev => [...prev, userMessage])

      // Send message and get response
      const chatMessage = await chatAPI.sendMessage(user.id, message, messageType, imageUrl)
      
      // Replace temporary message with real one
      setMessages(prev => 
        prev.map(msg => 
          msg.id === userMessage.id ? chatMessage : msg
        )
      )
      
      return chatMessage
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to send message')
      // Remove temporary message on error
      setMessages(prev => prev.filter(msg => !msg.id.startsWith('temp-')))
      throw err
    }
  }

  const clearChat = () => {
    setMessages([])
  }

  return {
    messages,
    loading,
    error,
    sendMessage,
    clearChat,
    refreshChat: loadChatHistory
  }
}