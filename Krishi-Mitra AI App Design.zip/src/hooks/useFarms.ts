import { useState, useEffect } from 'react'
import { farmAPI } from '../lib/api'
import type { Farm } from '../lib/supabase'
import { useAuth } from './useAuth'

export function useFarms() {
  const { user } = useAuth()
  const [farms, setFarms] = useState<Farm[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    if (user) {
      loadFarms()
    } else {
      setFarms([])
      setLoading(false)
    }
  }, [user])

  const loadFarms = async () => {
    if (!user) return
    
    try {
      setLoading(true)
      const farmsData = await farmAPI.getUserFarms(user.id)
      setFarms(farmsData)
      setError(null)
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to load farms')
    } finally {
      setLoading(false)
    }
  }

  const createFarm = async (farmData: Omit<Farm, 'id' | 'user_id' | 'created_at' | 'updated_at'>) => {
    if (!user) throw new Error('User not authenticated')

    try {
      const newFarm = await farmAPI.createFarm({
        ...farmData,
        user_id: user.id
      })
      setFarms(prev => [newFarm, ...prev])
      return newFarm
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to create farm')
      throw err
    }
  }

  const updateFarm = async (farmId: string, updates: Partial<Farm>) => {
    try {
      const updatedFarm = await farmAPI.updateFarm(farmId, updates)
      setFarms(prev => prev.map(farm => 
        farm.id === farmId ? updatedFarm : farm
      ))
      return updatedFarm
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to update farm')
      throw err
    }
  }

  const deleteFarm = async (farmId: string) => {
    try {
      await farmAPI.deleteFarm(farmId)
      setFarms(prev => prev.filter(farm => farm.id !== farmId))
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to delete farm')
      throw err
    }
  }

  return {
    farms,
    loading,
    error,
    createFarm,
    updateFarm,
    deleteFarm,
    refreshFarms: loadFarms
  }
}

export function useFarm(farmId: string | null) {
  const [farm, setFarm] = useState<Farm | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    if (farmId) {
      loadFarm(farmId)
    } else {
      setFarm(null)
      setLoading(false)
    }
  }, [farmId])

  const loadFarm = async (id: string) => {
    try {
      setLoading(true)
      const farmData = await farmAPI.getFarm(id)
      setFarm(farmData)
      setError(null)
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to load farm')
    } finally {
      setLoading(false)
    }
  }

  return { farm, loading, error, refreshFarm: () => farmId && loadFarm(farmId) }
}