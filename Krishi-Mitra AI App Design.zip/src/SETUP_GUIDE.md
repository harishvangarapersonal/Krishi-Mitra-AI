# Krishi-Mitra AI - Backend Setup Guide

## Overview
This guide will help you set up the complete backend infrastructure for your Krishi-Mitra AI application using Supabase.

## Prerequisites
- A Supabase account (https://supabase.com)
- Your Supabase project created and connected to this Figma Make project

## Database Setup

### Step 1: Run the Database Schema
1. Go to your Supabase dashboard
2. Navigate to the SQL Editor
3. Copy and paste the entire content from `/lib/database-schema.sql`
4. Execute the SQL script

This will create:
- All necessary tables with proper relationships
- Row Level Security (RLS) policies
- Indexes for optimal performance
- Triggers for automatic timestamps
- Custom types and enums

### Step 2: Configure Storage (for Disease Scan images)
1. Go to Storage in your Supabase dashboard
2. Create a new bucket called `disease-scans`
3. Make it public so users can view their uploaded images
4. Set appropriate file size limits (recommended: 10MB max)

## Environment Variables
Make sure these environment variables are set in your project:

```env
NEXT_PUBLIC_SUPABASE_URL=your_supabase_url
NEXT_PUBLIC_SUPABASE_ANON_KEY=your_supabase_anon_key
```

## Features Implemented

### 🔐 Authentication System
- User registration with email/password
- Automatic profile creation on signup
- Secure login/logout
- Profile management with language preferences

### 🚜 Farm Management
- Create and manage multiple farms per user
- Location-based farm data
- Farm size, irrigation, and crop history tracking
- Soft delete functionality

### 🤖 AI Crop Recommendations
- Generate personalized crop recommendations
- Save recommendation history
- Profit analysis and sustainability scoring
- Location and weather-based suggestions

### 💬 Real-time Chat System
- AI Kisan Assistant with chat history
- Real-time message synchronization
- Support for text, image, and voice messages
- Persistent conversation storage

### 🔍 Disease Detection
- Image upload and storage
- AI-powered disease identification
- Treatment recommendations
- Severity level assessment

### 📊 Yield Forecasting
- Crop yield predictions
- Weather impact analysis
- Historical data tracking
- Confidence scoring

### 🌱 Sustainability Reports
- Environmental impact analysis
- Water usage efficiency metrics
- Carbon footprint calculations
- Sustainability recommendations

### 🌤️ Weather Integration
- Location-based weather data
- Historical weather patterns
- Real-time conditions

### 💰 Market Price Tracking
- Crop price monitoring
- Market demand analysis
- Price trend predictions
- Location-specific pricing

## API Functions Available

### Authentication
```typescript
import { authAPI } from './lib/api'

// Sign up
await authAPI.signUp(email, password, userData)

// Sign in
await authAPI.signIn(email, password)

// Sign out
await authAPI.signOut()
```

### Farm Management
```typescript
import { farmAPI } from './lib/api'

// Create farm
await farmAPI.createFarm(farmData)

// Get user's farms
const farms = await farmAPI.getUserFarms(userId)

// Update farm
await farmAPI.updateFarm(farmId, updates)
```

### Crop Recommendations
```typescript
import { recommendationAPI } from './lib/api'

// Generate recommendations
const recommendations = await recommendationAPI.getCropRecommendations(inputData)

// Save recommendations
await recommendationAPI.saveRecommendation(data)
```

### Chat System
```typescript
import { chatAPI } from './lib/api'

// Send message
await chatAPI.sendMessage(userId, message)

// Get chat history
const messages = await chatAPI.getChatHistory(userId)

// Subscribe to real-time messages
chatAPI.subscribeToMessages(userId, callback)
```

## React Hooks

The application includes custom hooks for easy data management:

- `useAuth()` - Authentication state and methods
- `useFarms()` - Farm management
- `useRecommendations()` - Crop recommendations
- `useChat()` - Chat functionality

## Security Features

### Row Level Security (RLS)
All tables have RLS policies ensuring users can only access their own data:
- Users can only see their own farms, recommendations, chat messages, etc.
- Weather and market price data is publicly readable
- Automatic data isolation per user

### Data Validation
- Input validation on frontend and backend
- Type safety with TypeScript
- Proper error handling and user feedback

## Next Steps

### 1. AI Integration
Replace mock AI responses with real AI services:
- Integrate with OpenAI, Google AI, or custom ML models
- Connect to weather APIs (OpenWeatherMap, AccuWeather)
- Integrate market price APIs

### 2. Advanced Features
- Push notifications for weather alerts
- Offline functionality with sync
- Advanced analytics dashboard
- Export functionality for reports

### 3. Performance Optimization
- Implement caching strategies
- Add database indexes for specific queries
- Optimize image storage and delivery

### 4. Monitoring and Analytics
- Set up error tracking (Sentry)
- Add user analytics
- Database performance monitoring

## Troubleshooting

### Common Issues

1. **RLS Policies**: If users can't access their data, check RLS policies are correctly applied
2. **Storage Issues**: Ensure the disease-scans bucket is created and public
3. **Environment Variables**: Verify all Supabase environment variables are correctly set
4. **Database Permissions**: Make sure the service role has necessary permissions

### Support
For technical support or questions about the implementation, refer to the Supabase documentation or contact your development team.

## Database Schema Overview

```
Users (extends auth.users)
├── Farms (user's farm information)
├── Crop Recommendations (AI-generated suggestions)
├── Chat Messages (AI assistant conversations)
├── Disease Scans (plant disease detection)
├── Yield Forecasts (crop yield predictions)
├── Sustainability Reports (environmental impact)
└── User Preferences (app settings)

Public Tables:
├── Weather Data (location-based weather)
└── Market Prices (crop pricing information)
```

This backend provides a solid foundation for your agricultural AI application with room for growth and customization based on your specific needs.