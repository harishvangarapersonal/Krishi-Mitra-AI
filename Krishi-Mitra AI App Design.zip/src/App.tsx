import { useState } from 'react';
import { AuthProvider, useAuth } from './hooks/useAuth';
import { HomePage } from './components/HomePage';
import { FarmerInputPage } from './components/FarmerInputPage';
import { UnifiedResultsPage } from './components/UnifiedResultsPage';
import { YieldForecastPage } from './components/YieldForecastPage';
import { SustainabilityPage } from './components/SustainabilityPage';
import { RecommendationsPage } from './components/RecommendationsPage';
import { DiseaseScanPage } from './components/DiseaseScanPage';
import { ChatbotPage } from './components/ChatbotPage';
import { ProfilePage } from './components/ProfilePage';
import { BottomNavigation } from './components/BottomNavigation';
import { AuthScreen } from './components/AuthScreen';
import { LoadingScreen } from './components/LoadingScreen';

function AppContent() {
  const [currentScreen, setCurrentScreen] = useState('home');
  const { user, loading } = useAuth();

  const handleNavigate = (screen: string) => {
    setCurrentScreen(screen);
  };

  if (loading) {
    return <LoadingScreen />;
  }

  if (!user) {
    return <AuthScreen />;
  }

  const renderScreen = () => {
    switch (currentScreen) {
      case 'home':
        return <HomePage onNavigate={handleNavigate} />;
      case 'farmer-input':
        return <FarmerInputPage onNavigate={handleNavigate} />;
      case 'unified-results':
        return <UnifiedResultsPage onNavigate={handleNavigate} />;
      case 'yield-forecast':
        return <YieldForecastPage onNavigate={handleNavigate} />;
      case 'sustainability':
        return <SustainabilityPage onNavigate={handleNavigate} />;
      case 'recommendations':
        return <RecommendationsPage onNavigate={handleNavigate} />;
      case 'disease-scan':
        return <DiseaseScanPage onNavigate={handleNavigate} />;
      case 'chatbot':
        return <ChatbotPage onNavigate={handleNavigate} />;
      case 'profile':
        return <ProfilePage onNavigate={handleNavigate} />;
      default:
        return <HomePage onNavigate={handleNavigate} />;
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-md mx-auto bg-background min-h-screen relative">
        {renderScreen()}
        <BottomNavigation currentScreen={currentScreen} onNavigate={handleNavigate} />
      </div>
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  );
}