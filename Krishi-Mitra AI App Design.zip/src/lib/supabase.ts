/**
 * Supabase Configuration for Krishi-Mitra AI
 * 
 * TO CONNECT YOUR SUPABASE:
 * 1. Go to /lib/config.ts
 * 2. Replace YOUR_SUPABASE_URL_HERE with your actual Supabase URL
 * 3. Replace YOUR_SUPABASE_ANON_KEY_HERE with your actual Supabase anon key
 * 4. Set demo.enabled to false in config.ts
 * 
 * The app currently runs in demo mode with mock data.
 */

import { createClient } from '@supabase/supabase-js'
import { config, isDemoMode } from './config'

// Create Supabase client with fallback for demo mode
export const supabase = createClient(
  isDemoMode() ? 'https://demo.supabase.co' : config.supabase.url,
  isDemoMode() ? 'demo-key' : config.supabase.anonKey
)

// Database Types
export interface User {
  id: string
  email: string
  name: string
  phone?: string
  location: string
  language: 'english' | 'hindi' | 'telugu'
  created_at: string
  updated_at: string
}

export interface Farm {
  id: string
  user_id: string
  name: string
  size: number
  size_unit: 'acres' | 'hectares'
  location: {
    state: string
    district: string
    latitude?: number
    longitude?: number
  }
  soil_type: string
  irrigation_source: 'rainwater' | 'borewell' | 'canal' | 'river'
  previous_crop?: string
  created_at: string
  updated_at: string
}

export interface CropRecommendation {
  id: string
  user_id: string
  farm_id: string
  season: string
  recommendations: {
    crop: string
    yield_estimate: string
    profit_estimate: {
      min: number
      max: number
    }
    sustainability_score: number
    remarks: string
    confidence_score: number
  }[]
  input_data: {
    farm_size: number
    irrigation: string
    previous_crop: string
    location: any
    weather_conditions: any
  }
  created_at: string
}

export interface ChatMessage {
  id: string
  user_id: string
  message: string
  response: string
  message_type: 'text' | 'image' | 'voice'
  image_url?: string
  created_at: string
}

export interface DiseaseScan {
  id: string
  user_id: string
  image_url: string
  detected_disease?: string
  confidence_score?: number
  treatment_recommendations?: string[]
  severity_level?: 'low' | 'medium' | 'high'
  created_at: string
}

export interface YieldForecast {
  id: string
  user_id: string
  farm_id: string
  crop: string
  planting_date: string
  expected_harvest_date: string
  yield_prediction: {
    estimated_yield: number
    yield_unit: string
    confidence_level: number
    factors_considered: string[]
  }
  weather_impact: any
  created_at: string
}

export interface SustainabilityReport {
  id: string
  user_id: string
  farm_id: string
  crop: string
  sustainability_metrics: {
    water_usage_efficiency: number
    soil_health_impact: number
    carbon_footprint: number
    biodiversity_impact: number
    overall_score: number
  }
  recommendations: string[]
  created_at: string
}

export interface WeatherData {
  id: string
  location: string
  date: string
  temperature: {
    min: number
    max: number
    current: number
  }
  humidity: number
  rainfall: number
  wind_speed: number
  conditions: string
  created_at: string
}

export interface MarketPrice {
  id: string
  crop: string
  location: string
  price_per_kg: number
  market_demand: 'low' | 'medium' | 'high'
  price_trend: 'increasing' | 'stable' | 'decreasing'
  last_updated: string
}