// Configuration for Krishi-Mitra AI

export const config = {
  // Supabase Configuration
  supabase: {
    url: 'YOUR_SUPABASE_URL_HERE',
    anonKey: 'YOUR_SUPABASE_ANON_KEY_HERE'
  },
  
  // Demo mode settings
  demo: {
    enabled: true, // Set to false when you have real Supabase credentials
    user: {
      id: 'demo-user-id',
      email: 'demo@krishimitra.ai',
      name: 'Lakhan Kumar',
      phone: '+91 9876543210',
      location: 'Ranchi, Jharkhand',
      language: 'english' as const
    }
  },

  // API endpoints for external services (when ready)
  apis: {
    weather: 'https://api.openweathermap.org/data/2.5',
    cropPrices: 'https://api.data.gov.in/resource/9ef84268-d588-465a-a308-a864a43d0070'
  }
}

export const isDemoMode = () => {
  return config.demo.enabled || 
         config.supabase.url === 'YOUR_SUPABASE_URL_HERE' ||
         config.supabase.anonKey === 'YOUR_SUPABASE_ANON_KEY_HERE'
}