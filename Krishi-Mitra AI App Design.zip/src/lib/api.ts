import { supabase } from './supabase'
import { config, isDemoMode } from './config'
import type { 
  User, Farm, CropRecommendation, ChatMessage, DiseaseScan, 
  YieldForecast, SustainabilityReport, WeatherData, MarketPrice 
} from './supabase'

// Authentication API
export const authAPI = {
  async signUp(email: string, password: string, userData: { name: string; phone?: string; location: string }) {
    if (isDemoMode()) {
      // Demo mode - return mock successful signup
      return {
        data: {
          user: {
            id: config.demo.user.id,
            email,
            ...userData
          }
        },
        error: null
      }
    }

    const { data, error } = await supabase.auth.signUp({
      email,
      password,
      options: {
        data: userData
      }
    })
    return { data, error }
  },

  async signIn(email: string, password: string) {
    if (isDemoMode()) {
      // Demo mode - return mock successful signin
      return {
        data: {
          user: {
            id: config.demo.user.id,
            email: config.demo.user.email,
            name: config.demo.user.name
          },
          session: {
            user: {
              id: config.demo.user.id,
              email: config.demo.user.email
            }
          }
        },
        error: null
      }
    }

    const { data, error } = await supabase.auth.signInWithPassword({
      email,
      password
    })
    return { data, error }
  },

  async signOut() {
    if (isDemoMode()) {
      return { error: null }
    }

    const { error } = await supabase.auth.signOut()
    return { error }
  },

  async getCurrentUser() {
    if (isDemoMode()) {
      return {
        id: config.demo.user.id,
        email: config.demo.user.email,
        name: config.demo.user.name
      }
    }

    const { data: { user } } = await supabase.auth.getUser()
    return user
  },

  onAuthStateChange(callback: (event: string, session: any) => void) {
    if (isDemoMode()) {
      // In demo mode, immediately call with signed in user
      setTimeout(() => {
        callback('SIGNED_IN', {
          user: {
            id: config.demo.user.id,
            email: config.demo.user.email,
            name: config.demo.user.name
          }
        })
      }, 100)
      
      return {
        data: { subscription: { unsubscribe: () => {} } }
      }
    }

    return supabase.auth.onAuthStateChange(callback)
  }
}

// User Profile API
export const userAPI = {
  async getProfile(userId: string): Promise<User | null> {
    if (isDemoMode()) {
      return {
        ...config.demo.user,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString()
      }
    }

    const { data, error } = await supabase
      .from('users')
      .select('*')
      .eq('id', userId)
      .single()
    
    if (error) throw error
    return data
  },

  async updateProfile(userId: string, updates: Partial<User>) {
    if (isDemoMode()) {
      return {
        ...config.demo.user,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
        ...updates
      }
    }

    const { data, error } = await supabase
      .from('users')
      .update(updates)
      .eq('id', userId)
      .select()
      .single()
    
    if (error) throw error
    return data
  },

  async getUserPreferences(userId: string) {
    const { data, error } = await supabase
      .from('user_preferences')
      .select('*')
      .eq('user_id', userId)
      .single()
    
    if (error) throw error
    return data
  },

  async updateUserPreferences(userId: string, preferences: any) {
    const { data, error } = await supabase
      .from('user_preferences')
      .upsert({ user_id: userId, ...preferences })
      .select()
      .single()
    
    if (error) throw error
    return data
  }
}

// Farm Management API
export const farmAPI = {
  async createFarm(farmData: Omit<Farm, 'id' | 'created_at' | 'updated_at'>) {
    if (isDemoMode()) {
      return {
        id: 'demo-farm-id',
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
        ...farmData
      }
    }

    const { data, error } = await supabase
      .from('farms')
      .insert(farmData)
      .select()
      .single()
    
    if (error) throw error
    return data
  },

  async getUserFarms(userId: string): Promise<Farm[]> {
    if (isDemoMode()) {
      return [
        {
          id: 'demo-farm-id',
          user_id: userId,
          name: 'My Farm',
          size: 2.5,
          size_unit: 'acres',
          location: {
            state: 'Jharkhand',
            district: 'Ranchi',
            latitude: 23.3441,
            longitude: 85.3096
          },
          soil_type: 'Clay loam',
          irrigation_source: 'borewell',
          previous_crop: 'Wheat',
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString()
        }
      ]
    }

    const { data, error } = await supabase
      .from('farms')
      .select('*')
      .eq('user_id', userId)
      .eq('is_active', true)
      .order('created_at', { ascending: false })
    
    if (error) throw error
    return data || []
  },

  async getFarm(farmId: string): Promise<Farm | null> {
    const { data, error } = await supabase
      .from('farms')
      .select('*')
      .eq('id', farmId)
      .single()
    
    if (error) throw error
    return data
  },

  async updateFarm(farmId: string, updates: Partial<Farm>) {
    const { data, error } = await supabase
      .from('farms')
      .update(updates)
      .eq('id', farmId)
      .select()
      .single()
    
    if (error) throw error
    return data
  },

  async deleteFarm(farmId: string) {
    const { error } = await supabase
      .from('farms')
      .update({ is_active: false })
      .eq('id', farmId)
    
    if (error) throw error
    return true
  }
}

// Crop Recommendation API
export const recommendationAPI = {
  async getCropRecommendations(inputData: any) {
    // This would typically call your AI service
    // For now, return mock data based on input
    const mockRecommendations = [
      {
        crop: 'Bajra (Pearl Millet)',
        yield_estimate: '1.5 - 2.0 tons/hectare',
        profit_estimate: { min: 25000, max: 30000 },
        sustainability_score: 92,
        remarks: 'Low water use, improves soil health',
        confidence_score: 0.88
      },
      {
        crop: 'Maize',
        yield_estimate: '2.2 - 2.8 tons/hectare',
        profit_estimate: { min: 22000, max: 27000 },
        sustainability_score: 78,
        remarks: 'Good market demand, moderate water requirement',
        confidence_score: 0.82
      },
      {
        crop: 'Cotton',
        yield_estimate: '1.8 - 2.3 tons/hectare',
        profit_estimate: { min: 20000, max: 25000 },
        sustainability_score: 65,
        remarks: 'High profit potential, requires careful management',
        confidence_score: 0.75
      }
    ]

    return mockRecommendations
  },

  async saveRecommendation(recommendationData: Omit<CropRecommendation, 'id' | 'created_at'>) {
    if (isDemoMode()) {
      return {
        id: 'demo-recommendation-id',
        created_at: new Date().toISOString(),
        ...recommendationData
      }
    }

    const { data, error } = await supabase
      .from('crop_recommendations')
      .insert(recommendationData)
      .select()
      .single()
    
    if (error) throw error
    return data
  },

  async getUserRecommendations(userId: string, limit = 10): Promise<CropRecommendation[]> {
    if (isDemoMode()) {
      return [
        {
          id: 'demo-recommendation-id',
          user_id: userId,
          farm_id: 'demo-farm-id',
          season: 'current',
          recommendations: [
            {
              crop: 'Bajra (Pearl Millet)',
              yield_estimate: '1.5 - 2.0 tons/hectare',
              profit_estimate: { min: 25000, max: 30000 },
              sustainability_score: 92,
              remarks: 'Low water use, improves soil health',
              confidence_score: 0.88
            },
            {
              crop: 'Maize',
              yield_estimate: '2.2 - 2.8 tons/hectare',
              profit_estimate: { min: 22000, max: 27000 },
              sustainability_score: 78,
              remarks: 'Good market demand, moderate water requirement',
              confidence_score: 0.82
            },
            {
              crop: 'Cotton',
              yield_estimate: '1.8 - 2.3 tons/hectare',
              profit_estimate: { min: 20000, max: 25000 },
              sustainability_score: 65,
              remarks: 'High profit potential, requires careful management',
              confidence_score: 0.75
            }
          ],
          input_data: {
            farm_size: 2.5,
            irrigation: 'borewell',
            previous_crop: 'wheat',
            location: { state: 'jh', district: 'ranchi' },
            weather_conditions: {}
          },
          created_at: new Date().toISOString()
        }
      ]
    }

    const { data, error } = await supabase
      .from('crop_recommendations')
      .select('*')
      .eq('user_id', userId)
      .order('created_at', { ascending: false })
      .limit(limit)
    
    if (error) throw error
    return data || []
  }
}

// Chat API
export const chatAPI = {
  async sendMessage(userId: string, message: string, messageType: 'text' | 'image' | 'voice' = 'text', imageUrl?: string) {
    // Mock AI response - replace with actual AI integration
    const aiResponse = generateAIResponse(message)
    
    if (isDemoMode()) {
      return {
        id: `demo-message-${Date.now()}`,
        user_id: userId,
        message,
        response: aiResponse,
        message_type: messageType,
        image_url: imageUrl,
        created_at: new Date().toISOString()
      }
    }
    
    const { data, error } = await supabase
      .from('chat_messages')
      .insert({
        user_id: userId,
        message,
        response: aiResponse,
        message_type: messageType,
        image_url: imageUrl
      })
      .select()
      .single()
    
    if (error) throw error
    return data
  },

  async getChatHistory(userId: string, limit = 50): Promise<ChatMessage[]> {
    if (isDemoMode()) {
      return []
    }

    const { data, error } = await supabase
      .from('chat_messages')
      .select('*')
      .eq('user_id', userId)
      .order('created_at', { ascending: false })
      .limit(limit)
    
    if (error) throw error
    return (data || []).reverse() // Return in chronological order
  },

  subscribeToMessages(userId: string, callback: (message: ChatMessage) => void) {
    if (isDemoMode()) {
      return {
        unsubscribe: () => {}
      }
    }

    return supabase
      .channel('chat-messages')
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'chat_messages',
          filter: `user_id=eq.${userId}`
        },
        (payload) => callback(payload.new as ChatMessage)
      )
      .subscribe()
  }
}

// Disease Detection API
export const diseaseAPI = {
  async analyzePlantImage(userId: string, imageFile: File, farmId?: string) {
    // Upload image to Supabase Storage
    const fileExt = imageFile.name.split('.').pop()
    const fileName = `${userId}/${Date.now()}.${fileExt}`
    
    const { data: uploadData, error: uploadError } = await supabase.storage
      .from('disease-scans')
      .upload(fileName, imageFile)
    
    if (uploadError) throw uploadError

    const { data: { publicUrl } } = supabase.storage
      .from('disease-scans')
      .getPublicUrl(fileName)

    // Mock disease detection - replace with actual AI service
    const mockDetection = {
      detected_disease: 'Leaf Blight',
      confidence_score: 0.85,
      treatment_recommendations: [
        'Apply copper-based fungicide',
        'Improve air circulation',
        'Remove affected leaves'
      ],
      severity_level: 'medium' as const
    }

    const { data, error } = await supabase
      .from('disease_scans')
      .insert({
        user_id: userId,
        farm_id: farmId,
        image_url: publicUrl,
        ...mockDetection
      })
      .select()
      .single()
    
    if (error) throw error
    return data
  },

  async getDiseaseScans(userId: string, limit = 20): Promise<DiseaseScan[]> {
    const { data, error } = await supabase
      .from('disease_scans')
      .select('*')
      .eq('user_id', userId)
      .order('created_at', { ascending: false })
      .limit(limit)
    
    if (error) throw error
    return data || []
  }
}

// Yield Forecasting API
export const yieldAPI = {
  async createYieldForecast(forecastData: Omit<YieldForecast, 'id' | 'created_at'>) {
    const { data, error } = await supabase
      .from('yield_forecasts')
      .insert(forecastData)
      .select()
      .single()
    
    if (error) throw error
    return data
  },

  async getYieldForecasts(userId: string, farmId?: string): Promise<YieldForecast[]> {
    let query = supabase
      .from('yield_forecasts')
      .select('*')
      .eq('user_id', userId)
      .order('created_at', { ascending: false })

    if (farmId) {
      query = query.eq('farm_id', farmId)
    }

    const { data, error } = await query
    if (error) throw error
    return data || []
  },

  async generateYieldPrediction(farmData: any, cropData: any) {
    // Mock yield prediction - replace with actual ML model
    const basePrediction = {
      estimated_yield: 2.5,
      yield_unit: 'tons/hectare',
      confidence_level: 0.78,
      factors_considered: [
        'Soil type and fertility',
        'Historical weather patterns',
        'Crop variety characteristics',
        'Irrigation availability',
        'Local farming practices'
      ]
    }

    return basePrediction
  }
}

// Sustainability API
export const sustainabilityAPI = {
  async createSustainabilityReport(reportData: Omit<SustainabilityReport, 'id' | 'created_at'>) {
    const { data, error } = await supabase
      .from('sustainability_reports')
      .insert(reportData)
      .select()
      .single()
    
    if (error) throw error
    return data
  },

  async getSustainabilityReports(userId: string, farmId?: string): Promise<SustainabilityReport[]> {
    let query = supabase
      .from('sustainability_reports')
      .select('*')
      .eq('user_id', userId)
      .order('created_at', { ascending: false })

    if (farmId) {
      query = query.eq('farm_id', farmId)
    }

    const { data, error } = await query
    if (error) throw error
    return data || []
  },

  async analyzeSustainability(farmData: any, cropData: any) {
    // Mock sustainability analysis - replace with actual calculations
    const mockAnalysis = {
      water_usage_efficiency: 85,
      soil_health_impact: 92,
      carbon_footprint: 73,
      biodiversity_impact: 88,
      overall_score: 84
    }

    const recommendations = [
      'Consider drip irrigation to improve water efficiency',
      'Implement crop rotation to enhance soil health',
      'Use organic fertilizers to reduce carbon footprint',
      'Plant native species around field borders'
    ]

    return { ...mockAnalysis, recommendations }
  }
}

// Weather API
export const weatherAPI = {
  async getWeatherData(location: string, days = 7): Promise<WeatherData[]> {
    const { data, error } = await supabase
      .from('weather_data')
      .select('*')
      .eq('location', location)
      .gte('date', new Date(Date.now() - days * 24 * 60 * 60 * 1000).toISOString())
      .order('date', { ascending: false })
    
    if (error) throw error
    return data || []
  },

  async getCurrentWeather(location: string) {
    // Mock current weather - replace with actual weather API
    return {
      temperature: { min: 22, max: 32, current: 28 },
      humidity: 65,
      conditions: 'Partly Cloudy',
      rainfall: 0,
      wind_speed: 12
    }
  }
}

// Market Price API
export const marketAPI = {
  async getMarketPrices(crop?: string, location?: string): Promise<MarketPrice[]> {
    let query = supabase
      .from('market_prices')
      .select('*')
      .order('last_updated', { ascending: false })

    if (crop) {
      query = query.eq('crop', crop)
    }
    if (location) {
      query = query.eq('location', location)
    }

    const { data, error } = await query
    if (error) throw error
    return data || []
  },

  async getCropPrice(crop: string, location: string): Promise<MarketPrice | null> {
    const { data, error } = await supabase
      .from('market_prices')
      .select('*')
      .eq('crop', crop)
      .eq('location', location)
      .single()
    
    if (error) return null
    return data
  }
}

// Utility function for AI responses
function generateAIResponse(message: string): string {
  const responses = [
    "Based on your location and current conditions, I recommend considering drought-resistant crops like bajra or jowar for the upcoming season.",
    "For optimal irrigation efficiency, drip irrigation systems can help you save water while maintaining good crop yields.",
    "The soil analysis shows good organic content. Consider crop rotation with legumes to maintain soil health naturally.",
    "Current market trends indicate good demand for millets and pulses in your region.",
    "Weather patterns suggest the monsoon will be favorable this year. Consider crops that benefit from good rainfall.",
    "For sustainable farming, I recommend reducing chemical fertilizer use and incorporating organic matter.",
  ]
  
  return responses[Math.floor(Math.random() * responses.length)]
}