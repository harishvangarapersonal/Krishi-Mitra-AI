-- Krishi-Mitra AI Database Schema
-- Run this SQL in your Supabase SQL Editor

-- Enable necessary extensions
create extension if not exists "uuid-ossp";

-- Create custom types
create type language_type as enum ('english', 'hindi', 'telugu');
create type size_unit_type as enum ('acres', 'hectares');
create type irrigation_type as enum ('rainwater', 'borewell', 'canal', 'river');
create type message_type as enum ('text', 'image', 'voice');
create type severity_level as enum ('low', 'medium', 'high');
create type demand_level as enum ('low', 'medium', 'high');
create type trend_type as enum ('increasing', 'stable', 'decreasing');

-- Users table (extends Supabase auth.users)
create table public.users (
  id uuid references auth.users on delete cascade primary key,
  email text unique not null,
  name text not null,
  phone text,
  location text not null,
  language language_type default 'english',
  avatar_url text,
  created_at timestamp with time zone default timezone('utc'::text, now()) not null,
  updated_at timestamp with time zone default timezone('utc'::text, now()) not null
);

-- Farms table
create table public.farms (
  id uuid default uuid_generate_v4() primary key,
  user_id uuid references public.users(id) on delete cascade not null,
  name text not null,
  size numeric not null,
  size_unit size_unit_type not null,
  location jsonb not null, -- {state, district, latitude, longitude}
  soil_type text not null,
  irrigation_source irrigation_type not null,
  previous_crop text,
  is_active boolean default true,
  created_at timestamp with time zone default timezone('utc'::text, now()) not null,
  updated_at timestamp with time zone default timezone('utc'::text, now()) not null
);

-- Crop recommendations table
create table public.crop_recommendations (
  id uuid default uuid_generate_v4() primary key,
  user_id uuid references public.users(id) on delete cascade not null,
  farm_id uuid references public.farms(id) on delete cascade not null,
  season text not null,
  recommendations jsonb not null, -- Array of recommendation objects
  input_data jsonb not null, -- Farm and environmental data used
  created_at timestamp with time zone default timezone('utc'::text, now()) not null
);

-- Chat messages table
create table public.chat_messages (
  id uuid default uuid_generate_v4() primary key,
  user_id uuid references public.users(id) on delete cascade not null,
  message text not null,
  response text not null,
  message_type message_type default 'text',
  image_url text,
  metadata jsonb, -- Additional context, attachments, etc.
  created_at timestamp with time zone default timezone('utc'::text, now()) not null
);

-- Disease scans table
create table public.disease_scans (
  id uuid default uuid_generate_v4() primary key,
  user_id uuid references public.users(id) on delete cascade not null,
  farm_id uuid references public.farms(id) on delete cascade,
  image_url text not null,
  detected_disease text,
  confidence_score numeric,
  treatment_recommendations text[],
  severity_level severity_level,
  additional_notes text,
  created_at timestamp with time zone default timezone('utc'::text, now()) not null
);

-- Yield forecasts table
create table public.yield_forecasts (
  id uuid default uuid_generate_v4() primary key,
  user_id uuid references public.users(id) on delete cascade not null,
  farm_id uuid references public.farms(id) on delete cascade not null,
  crop text not null,
  planting_date date not null,
  expected_harvest_date date not null,
  yield_prediction jsonb not null, -- {estimated_yield, yield_unit, confidence_level, factors_considered}
  weather_impact jsonb,
  market_factors jsonb,
  created_at timestamp with time zone default timezone('utc'::text, now()) not null
);

-- Sustainability reports table
create table public.sustainability_reports (
  id uuid default uuid_generate_v4() primary key,
  user_id uuid references public.users(id) on delete cascade not null,
  farm_id uuid references public.farms(id) on delete cascade not null,
  crop text not null,
  sustainability_metrics jsonb not null, -- {water_usage, soil_health, carbon_footprint, etc.}
  recommendations text[],
  overall_score numeric,
  created_at timestamp with time zone default timezone('utc'::text, now()) not null
);

-- Weather data table
create table public.weather_data (
  id uuid default uuid_generate_v4() primary key,
  location text not null,
  date date not null,
  temperature jsonb not null, -- {min, max, current}
  humidity numeric not null,
  rainfall numeric not null,
  wind_speed numeric not null,
  conditions text not null,
  created_at timestamp with time zone default timezone('utc'::text, now()) not null,
  unique(location, date)
);

-- Market prices table
create table public.market_prices (
  id uuid default uuid_generate_v4() primary key,
  crop text not null,
  location text not null,
  price_per_kg numeric not null,
  market_demand demand_level not null,
  price_trend trend_type not null,
  last_updated timestamp with time zone default timezone('utc'::text, now()) not null,
  unique(crop, location)
);

-- User preferences table
create table public.user_preferences (
  id uuid default uuid_generate_v4() primary key,
  user_id uuid references public.users(id) on delete cascade not null unique,
  notifications_enabled boolean default true,
  auto_sync_enabled boolean default true,
  preferred_units jsonb default '{"temperature": "celsius", "area": "acres", "weight": "kg"}',
  dashboard_layout jsonb,
  created_at timestamp with time zone default timezone('utc'::text, now()) not null,
  updated_at timestamp with time zone default timezone('utc'::text, now()) not null
);

-- Create indexes for better performance
create index idx_farms_user_id on public.farms(user_id);
create index idx_farms_location on public.farms using gin(location);
create index idx_crop_recommendations_user_id on public.crop_recommendations(user_id);
create index idx_crop_recommendations_farm_id on public.crop_recommendations(farm_id);
create index idx_chat_messages_user_id on public.chat_messages(user_id);
create index idx_chat_messages_created_at on public.chat_messages(created_at desc);
create index idx_disease_scans_user_id on public.disease_scans(user_id);
create index idx_yield_forecasts_user_id on public.yield_forecasts(user_id);
create index idx_yield_forecasts_farm_id on public.yield_forecasts(farm_id);
create index idx_sustainability_reports_user_id on public.sustainability_reports(user_id);
create index idx_weather_data_location_date on public.weather_data(location, date desc);
create index idx_market_prices_crop_location on public.market_prices(crop, location);

-- Row Level Security (RLS) Policies
alter table public.users enable row level security;
alter table public.farms enable row level security;
alter table public.crop_recommendations enable row level security;
alter table public.chat_messages enable row level security;
alter table public.disease_scans enable row level security;
alter table public.yield_forecasts enable row level security;
alter table public.sustainability_reports enable row level security;
alter table public.user_preferences enable row level security;

-- Users can only see and modify their own data
create policy "Users can view own profile" on public.users
  for select using (auth.uid() = id);

create policy "Users can update own profile" on public.users
  for update using (auth.uid() = id);

-- Farms policies
create policy "Users can view own farms" on public.farms
  for select using (auth.uid() = user_id);

create policy "Users can insert own farms" on public.farms
  for insert with check (auth.uid() = user_id);

create policy "Users can update own farms" on public.farms
  for update using (auth.uid() = user_id);

create policy "Users can delete own farms" on public.farms
  for delete using (auth.uid() = user_id);

-- Crop recommendations policies
create policy "Users can view own recommendations" on public.crop_recommendations
  for select using (auth.uid() = user_id);

create policy "Users can insert own recommendations" on public.crop_recommendations
  for insert with check (auth.uid() = user_id);

-- Chat messages policies
create policy "Users can view own chat messages" on public.chat_messages
  for select using (auth.uid() = user_id);

create policy "Users can insert own chat messages" on public.chat_messages
  for insert with check (auth.uid() = user_id);

-- Disease scans policies
create policy "Users can view own disease scans" on public.disease_scans
  for select using (auth.uid() = user_id);

create policy "Users can insert own disease scans" on public.disease_scans
  for insert with check (auth.uid() = user_id);

-- Yield forecasts policies
create policy "Users can view own yield forecasts" on public.yield_forecasts
  for select using (auth.uid() = user_id);

create policy "Users can insert own yield forecasts" on public.yield_forecasts
  for insert with check (auth.uid() = user_id);

-- Sustainability reports policies
create policy "Users can view own sustainability reports" on public.sustainability_reports
  for select using (auth.uid() = user_id);

create policy "Users can insert own sustainability reports" on public.sustainability_reports
  for insert with check (auth.uid() = user_id);

-- User preferences policies
create policy "Users can view own preferences" on public.user_preferences
  for select using (auth.uid() = user_id);

create policy "Users can insert own preferences" on public.user_preferences
  for insert with check (auth.uid() = user_id);

create policy "Users can update own preferences" on public.user_preferences
  for update using (auth.uid() = user_id);

-- Weather data and market prices are public (read-only for users)
create policy "Anyone can view weather data" on public.weather_data
  for select using (true);

create policy "Anyone can view market prices" on public.market_prices
  for select using (true);

-- Functions for automatic profile creation
create or replace function public.handle_new_user() 
returns trigger as $$
begin
  insert into public.users (id, email, name, location)
  values (new.id, new.email, coalesce(new.raw_user_meta_data->>'name', 'Farmer'), 'India');
  
  insert into public.user_preferences (user_id)
  values (new.id);
  
  return new;
end;
$$ language plpgsql security definer;

-- Trigger to automatically create user profile
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure public.handle_new_user();

-- Function to update updated_at timestamp
create or replace function public.update_updated_at_column()
returns trigger as $$
begin
  new.updated_at = timezone('utc'::text, now());
  return new;
end;
$$ language plpgsql;

-- Add updated_at triggers
create trigger update_users_updated_at before update on public.users
  for each row execute procedure public.update_updated_at_column();

create trigger update_farms_updated_at before update on public.farms
  for each row execute procedure public.update_updated_at_column();

create trigger update_user_preferences_updated_at before update on public.user_preferences
  for each row execute procedure public.update_updated_at_column();