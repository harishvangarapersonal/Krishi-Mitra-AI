import { useState, useEffect, useRef } from 'react';
import { ArrowLeft, Send, Camera, Bot, User, Mic } from 'lucide-react';
import { useChat } from '../hooks/useChat';
import { toast } from 'sonner@2.0.3';
import { Card, CardContent } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';

interface ChatbotPageProps {
  onNavigate: (screen: string) => void;
}

export function ChatbotPage({ onNavigate }: ChatbotPageProps) {
  const { messages: chatMessages, sendMessage, loading } = useChat();
  const [inputMessage, setInputMessage] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Transform chat messages for display
  const messages = chatMessages.flatMap(msg => [
    {
      id: `user-${msg.id}`,
      content: msg.message,
      sender: 'user' as const,
      timestamp: new Date(msg.created_at),
      type: msg.message_type
    },
    {
      id: `ai-${msg.id}`,
      content: msg.response,
      sender: 'ai' as const,
      timestamp: new Date(msg.created_at),
      type: 'text' as const
    }
  ]);

  // Add initial greeting if no messages
  const displayMessages = messages.length === 0 ? [
    {
      id: 'greeting',
      content: "Hello! I'm your AI Kisan Assistant. I can help you with crop recommendations, farming techniques, disease identification, and answer any agriculture-related questions. How can I assist you today?",
      sender: 'ai' as const,
      timestamp: new Date(),
      type: 'text' as const
    }
  ] : messages;

  useEffect(() => {
    scrollToBottom();
  }, [displayMessages]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  const handleSendMessage = async () => {
    if (!inputMessage.trim()) return;

    const messageText = inputMessage;
    setInputMessage('');
    setIsTyping(true);

    try {
      await sendMessage(messageText);
    } catch (error: any) {
      toast.error('Failed to send message');
    } finally {
      setIsTyping(false);
    }
  };

  const handleCameraCapture = () => {
    onNavigate('disease-scan');
  };

  const getAIResponse = (input: string): string => {
    const responses = [
      "Based on your location in Jharkhand, I recommend considering drought-resistant crops like bajra or jowar for the upcoming season. These crops are well-suited to your soil conditions and current weather patterns.",
      "For optimal irrigation in your area, I suggest implementing drip irrigation systems to conserve water while maintaining good crop yields. This can increase your efficiency by 30-40%.",
      "The soil analysis shows good organic content. Consider crop rotation with legumes to maintain soil health and improve nitrogen levels naturally.",
      "Current market trends indicate good prices for millets and pulses. These align well with sustainable farming practices and your local growing conditions."
    ];
    return responses[Math.floor(Math.random() * responses.length)];
  };

  const formatTime = (date: Date) => {
    return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };

  const quickQuestions = [
    "What crops are best for my soil?",
    "How to improve crop yield?",
    "Pest control methods",
    "Market prices today"
  ];

  return (
    <div className="min-h-screen bg-background pb-20 flex flex-col">
      {/* Header */}
      <div className="sticky top-0 bg-background/90 backdrop-blur-md border-b border-border z-10">
        <div className="flex items-center justify-between px-6 py-4">
          <div className="flex items-center gap-3">
            <Button 
              variant="ghost" 
              size="sm"
              onClick={() => onNavigate('home')}
              className="p-2"
            >
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-gradient-to-br from-primary to-primary/80 flex items-center justify-center">
                <Bot className="w-5 h-5 text-white" />
              </div>
              <div>
                <h1 className="font-medium text-foreground">AI Kisan Assistant</h1>
                <p className="text-xs text-green-600">● Online</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Messages Area */}
      <div className="flex-1 px-6 py-6 space-y-4 overflow-y-auto">
        {/* Quick Questions */}
        {displayMessages.length === 1 && (
          <div className="mb-6">
            <p className="text-sm text-muted-foreground mb-3">Quick questions to get started:</p>
            <div className="grid grid-cols-2 gap-2">
              {quickQuestions.map((question, index) => (
                <Button
                  key={index}
                  variant="outline"
                  size="sm"
                  onClick={() => setInputMessage(question)}
                  className="h-auto p-3 text-xs text-left glass-button border-border/50 hover:bg-primary/5"
                >
                  {question}
                </Button>
              ))}
            </div>
          </div>
        )}

        {/* Messages */}
        {displayMessages.map((message) => (
          <div
            key={message.id}
            className={`flex gap-3 ${message.sender === 'user' ? 'flex-row-reverse' : ''}`}
          >
            {/* Avatar */}
            <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${
              message.sender === 'ai' 
                ? 'bg-gradient-to-br from-primary to-primary/80' 
                : 'bg-gradient-to-br from-orange-400 to-orange-500'
            }`}>
              {message.sender === 'ai' ? (
                <Bot className="w-4 h-4 text-white" />
              ) : (
                <User className="w-4 h-4 text-white" />
              )}
            </div>

            {/* Message Content */}
            <div className={`flex-1 max-w-[80%] ${message.sender === 'user' ? 'text-right' : ''}`}>
              <Card className={`glass-card border-0 organic-shadow ${
                message.sender === 'user' 
                  ? 'bg-primary/10 border-primary/20' 
                  : 'bg-card'
              }`}>
                <CardContent className="p-4">
                  <p className="text-foreground leading-relaxed">{message.content}</p>
                </CardContent>
              </Card>
              <p className="text-xs text-muted-foreground mt-1 px-2">
                {formatTime(message.timestamp)}
              </p>
            </div>
          </div>
        ))}

        <div ref={messagesEndRef} />

        {/* Typing Indicator */}
        {isTyping && (
          <div className="flex gap-3">
            <div className="w-8 h-8 rounded-full bg-gradient-to-br from-primary to-primary/80 flex items-center justify-center">
              <Bot className="w-4 h-4 text-white" />
            </div>
            <Card className="glass-card border-0 organic-shadow">
              <CardContent className="p-4">
                <div className="flex gap-1">
                  <div className="w-2 h-2 bg-primary/60 rounded-full animate-bounce"></div>
                  <div className="w-2 h-2 bg-primary/60 rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
                  <div className="w-2 h-2 bg-primary/60 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                </div>
              </CardContent>
            </Card>
          </div>
        )}
      </div>

      {/* Input Area */}
      <div className="px-6 py-4 border-t border-border bg-background/80 backdrop-blur-md">
        <div className="flex gap-3 items-end">
          <div className="flex-1">
            <Input
              value={inputMessage}
              onChange={(e) => setInputMessage(e.target.value)}
              placeholder="Type your farming question..."
              onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
              className="glass-button border-border/50 bg-input h-12 text-base"
            />
          </div>
          
          {/* Camera Button */}
          <Button
            onClick={handleCameraCapture}
            variant="outline"
            size="icon"
            className="h-12 w-12 glass-button border-border/50 hover:bg-primary/10"
          >
            <Camera className="w-5 h-5 text-primary" />
          </Button>

          {/* Send Button */}
          <Button
            onClick={handleSendMessage}
            disabled={!inputMessage.trim()}
            className="h-12 w-12 cta-glow disabled:opacity-50"
            style={{ backgroundColor: 'var(--cta)', color: 'var(--cta-foreground)' }}
          >
            <Send className="w-5 h-5" />
          </Button>
        </div>
        
        <p className="text-xs text-muted-foreground text-center mt-3">
          Tap the camera icon to scan plant diseases directly in chat
        </p>
      </div>
    </div>
  );
}