import { useState } from 'react';
import { ArrowLeft, Droplets, Leaf, Recycle, Award, TrendingUp, AlertCircle } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Progress } from './ui/progress';
import { RadialBarChart, RadialBar, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';

interface SustainabilityPageProps {
  onNavigate: (screen: string) => void;
}

export function SustainabilityPage({ onNavigate }: SustainabilityPageProps) {
  const [selectedCrop, setSelectedCrop] = useState('');
  const [showAnalysis, setShowAnalysis] = useState(false);

  const crops = ['Bajra', 'Maize', 'Rice', 'Wheat', 'Cotton', 'Soybean'];

  const sustainabilityData = [
    { name: 'Water Usage', value: 85, color: '#26A69A' },
    { name: 'Soil Health', value: 92, color: '#004D40' },
    { name: 'Carbon Impact', value: 78, color: '#4DB6AC' },
    { name: 'Biodiversity', value: 88, color: '#80CBC4' }
  ];

  const overallScore = Math.round(
    sustainabilityData.reduce((sum, item) => sum + item.value, 0) / sustainabilityData.length
  );

  const impactData = [
    { name: 'Positive', value: 65, color: '#4CAF50' },
    { name: 'Neutral', value: 25, color: '#FFC107' },
    { name: 'Needs Attention', value: 10, color: '#FF5722' }
  ];

  const handleAnalyze = () => {
    if (selectedCrop) {
      setShowAnalysis(true);
    }
  };

  return (
    <div className="min-h-screen bg-background pb-20">
      {/* Header */}
      <div className="sticky top-0 bg-background/80 backdrop-blur-md border-b border-border z-10">
        <div className="flex items-center justify-between px-6 py-4">
          <div className="flex items-center gap-3">
            <Button 
              variant="ghost" 
              size="sm"
              onClick={() => onNavigate('home')}
              className="p-2"
            >
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <div>
              <h1 className="font-medium text-foreground">Sustainability Check</h1>
              <p className="text-xs text-muted-foreground">Environmental impact assessment</p>
            </div>
          </div>
          <Leaf className="w-6 h-6 text-green-600" />
        </div>
      </div>

      <div className="px-6 py-6 space-y-6">
        {!showAnalysis ? (
          <>
            {/* Crop Selection */}
            <Card className="glass-card border-0">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Droplets className="w-5 h-5 text-primary" />
                  Select Crop for Analysis
                </CardTitle>
              </CardHeader>
              <CardContent>
                <Select value={selectedCrop} onValueChange={setSelectedCrop}>
                  <SelectTrigger className="glass-button border-border/50 bg-input">
                    <SelectValue placeholder="Choose crop to analyze" />
                  </SelectTrigger>
                  <SelectContent>
                    {crops.map((crop) => (
                      <SelectItem key={crop} value={crop.toLowerCase()}>
                        {crop}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </CardContent>
            </Card>

            {/* Sustainability Factors */}
            <Card className="glass-card border-0">
              <CardHeader>
                <CardTitle>What We Analyze</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 gap-4">
                  <div className="text-center p-4 bg-blue-50 rounded-lg">
                    <Droplets className="w-8 h-8 text-blue-600 mx-auto mb-2" />
                    <h4 className="font-medium text-foreground text-sm">Water Usage</h4>
                    <p className="text-xs text-muted-foreground">Irrigation efficiency</p>
                  </div>
                  <div className="text-center p-4 bg-green-50 rounded-lg">
                    <Leaf className="w-8 h-8 text-green-600 mx-auto mb-2" />
                    <h4 className="font-medium text-foreground text-sm">Soil Health</h4>
                    <p className="text-xs text-muted-foreground">Nutrient impact</p>
                  </div>
                  <div className="text-center p-4 bg-purple-50 rounded-lg">
                    <Recycle className="w-8 h-8 text-purple-600 mx-auto mb-2" />
                    <h4 className="font-medium text-foreground text-sm">Carbon Impact</h4>
                    <p className="text-xs text-muted-foreground">CO2 footprint</p>
                  </div>
                  <div className="text-center p-4 bg-orange-50 rounded-lg">
                    <Award className="w-8 h-8 text-orange-600 mx-auto mb-2" />
                    <h4 className="font-medium text-foreground text-sm">Biodiversity</h4>
                    <p className="text-xs text-muted-foreground">Ecosystem impact</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Button
              onClick={handleAnalyze}
              disabled={!selectedCrop}
              className="w-full h-14 bg-gradient-to-r from-green-600 to-green-500 hover:from-green-500 hover:to-green-400 text-white glass-button disabled:opacity-50"
            >
              <Leaf className="w-5 h-5 mr-2" />
              Analyze Sustainability
            </Button>
          </>
        ) : (
          <>
            {/* Overall Score */}
            <Card className="glass-card border-0">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Award className="w-5 h-5 text-green-600" />
                  Sustainability Score - {selectedCrop}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-center justify-center mb-4">
                  <div className="relative w-32 h-32">
                    <ResponsiveContainer width="100%" height="100%">
                      <RadialBarChart
                        cx="50%"
                        cy="50%"
                        innerRadius="60%"
                        outerRadius="90%"
                        data={[{ value: overallScore, fill: '#4CAF50' }]}
                        startAngle={90}
                        endAngle={-270}
                      >
                        <RadialBar
                          dataKey="value"
                          cornerRadius={10}
                          fill="#4CAF50"
                        />
                      </RadialBarChart>
                    </ResponsiveContainer>
                    <div className="absolute inset-0 flex items-center justify-center">
                      <div className="text-center">
                        <p className="text-2xl font-medium text-foreground">{overallScore}</p>
                        <p className="text-xs text-muted-foreground">Score</p>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="text-center">
                  <p className="font-medium text-green-600">Excellent Sustainability</p>
                  <p className="text-sm text-muted-foreground">Environmentally friendly choice</p>
                </div>
              </CardContent>
            </Card>

            {/* Detailed Metrics */}
            <Card className="glass-card border-0">
              <CardHeader>
                <CardTitle>Detailed Analysis</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {sustainabilityData.map((metric) => (
                  <div key={metric.name} className="space-y-2">
                    <div className="flex justify-between items-center">
                      <p className="text-sm font-medium text-foreground">{metric.name}</p>
                      <p className="text-sm font-medium" style={{ color: metric.color }}>
                        {metric.value}/100
                      </p>
                    </div>
                    <Progress 
                      value={metric.value} 
                      className="h-2"
                      style={{ '--progress-foreground': metric.color } as any}
                    />
                  </div>
                ))}
              </CardContent>
            </Card>

            {/* Impact Distribution */}
            <Card className="glass-card border-0">
              <CardHeader>
                <CardTitle>Environmental Impact</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-center justify-between mb-4">
                  <div className="w-24 h-24">
                    <ResponsiveContainer width="100%" height="100%">
                      <PieChart>
                        <Pie
                          data={impactData}
                          cx="50%"
                          cy="50%"
                          innerRadius={20}
                          outerRadius={40}
                          paddingAngle={5}
                          dataKey="value"
                        >
                          {impactData.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={entry.color} />
                          ))}
                        </Pie>
                      </PieChart>
                    </ResponsiveContainer>
                  </div>
                  <div className="flex-1 ml-4 space-y-2">
                    {impactData.map((item) => (
                      <div key={item.name} className="flex items-center gap-2">
                        <div 
                          className="w-3 h-3 rounded-full" 
                          style={{ backgroundColor: item.color }}
                        ></div>
                        <span className="text-sm text-foreground">{item.name}</span>
                        <span className="text-sm text-muted-foreground">{item.value}%</span>
                      </div>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Recommendations */}
            <Card className="glass-card border-0">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <TrendingUp className="w-5 h-5 text-accent" />
                  Improvement Suggestions
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex items-start gap-3 p-3 bg-green-50 rounded-lg">
                  <Award className="w-5 h-5 text-green-600 mt-0.5" />
                  <div>
                    <p className="text-sm font-medium text-green-900">Excellent water efficiency</p>
                    <p className="text-xs text-green-700">Continue current irrigation practices</p>
                  </div>
                </div>
                <div className="flex items-start gap-3 p-3 bg-yellow-50 rounded-lg">
                  <AlertCircle className="w-5 h-5 text-yellow-600 mt-0.5" />
                  <div>
                    <p className="text-sm font-medium text-yellow-900">Consider organic fertilizers</p>
                    <p className="text-xs text-yellow-700">Can improve carbon footprint by 15%</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <div className="grid grid-cols-2 gap-3">
              <Button
                variant="outline"
                onClick={() => setShowAnalysis(false)}
                className="h-12 glass-button border-border/50"
              >
                New Analysis
              </Button>
              <Button
                onClick={() => onNavigate('home')}
                className="h-12 bg-gradient-to-r from-green-600 to-green-500 text-white glass-button"
              >
                Save Report
              </Button>
            </div>
          </>
        )}
      </div>
    </div>
  );
}