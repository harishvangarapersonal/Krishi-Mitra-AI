import { ArrowRight, Sprout, Camera, MessageCircle, TrendingUp, Leaf, Sun, Cloud, Droplets } from 'lucide-react';
import { Card, CardContent } from './ui/card';
import { Button } from './ui/button';

interface HomePageProps {
  onNavigate: (screen: string) => void;
}

export function HomePage({ onNavigate }: HomePageProps) {
  const toolCards = [
    {
      id: 'crop-recommendation',
      title: 'Complete Crop Recommendation',
      description: 'AI-powered crop suggestions based on your farm data',
      icon: Sprout,
      primary: true,
      action: () => onNavigate('farmer-input')
    },
    {
      id: 'yield-forecast',
      title: 'Yield Forecaster',
      description: 'Predict your harvest quantities',
      icon: TrendingUp,
      action: () => onNavigate('yield-forecast')
    },
    {
      id: 'disease-scan',
      title: 'Disease Scan',
      description: 'Instant disease detection using camera',
      icon: Camera,
      action: () => onNavigate('disease-scan')
    },
    {
      id: 'ai-assistant',
      title: 'AI Kisan Assistant',
      description: 'Chat with farming expert AI',
      icon: MessageCircle,
      action: () => onNavigate('chatbot')
    }
  ];

  return (
    <div className="min-h-screen bg-background pb-20">
      {/* Header Section */}
      <div className="pt-8 px-6 pb-6">
        <div className="mb-6">
          <h1 className="text-3xl font-medium text-foreground mb-2">
            Good Morning, Farmer!
          </h1>
          <p className="text-muted-foreground">
            Your intelligent farming toolkit is ready to help you succeed
          </p>
        </div>

        {/* Weather & Status Card */}
        <Card className="glass-card border-0 mb-8 organic-shadow">
          <CardContent className="p-5">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-4">
                <div className="w-14 h-14 rounded-full bg-gradient-to-br from-yellow-400 to-orange-400 flex items-center justify-center organic-shadow">
                  <Sun className="w-7 h-7 text-white" />
                </div>
                <div>
                  <h3 className="font-medium text-foreground text-lg">Today's Conditions</h3>
                  <p className="text-muted-foreground">28°C • Partly Cloudy • Perfect for farming</p>
                </div>
              </div>
              <div className="text-right">
                <div className="flex items-center gap-1 text-primary font-medium">
                  <Leaf className="w-4 h-4" />
                  <span>Optimal</span>
                </div>
                <div className="flex items-center gap-2 text-sm text-muted-foreground mt-1">
                  <Droplets className="w-3 h-3" />
                  <span>Humidity: 65%</span>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Main Toolkit Section */}
      <div className="px-6">
        <div className="mb-6">
          <h2 className="text-xl font-medium text-foreground mb-2">
            Your Farmer's Toolkit
          </h2>
          <p className="text-muted-foreground">
            Select any tool to get started with AI-powered farming insights
          </p>
        </div>

        {/* Primary Tool Card - Complete Crop Recommendation */}
        <Card 
          className="glass-card border-0 mb-6 overflow-hidden cursor-pointer hover:scale-[1.02] transition-all duration-200 organic-shadow"
          onClick={() => onNavigate('farmer-input')}
        >
          <CardContent className="p-0">
            <div className="bg-gradient-to-br from-primary to-primary/90 p-6 text-white relative overflow-hidden">
              <div className="absolute top-0 right-0 w-32 h-32 bg-white/10 rounded-full -translate-y-16 translate-x-16"></div>
              <div className="absolute bottom-0 left-0 w-24 h-24 bg-white/5 rounded-full translate-y-12 -translate-x-12"></div>
              
              <div className="relative z-10">
                <div className="flex items-start justify-between mb-4">
                  <div className="flex-1">
                    <h3 className="text-xl font-medium mb-2">
                      Complete Crop Recommendation
                    </h3>
                    <p className="text-white/90 text-sm leading-relaxed">
                      Get personalized crop suggestions with detailed profit analysis and sustainability insights
                    </p>
                  </div>
                  <div className="w-12 h-12 rounded-full bg-white/20 flex items-center justify-center ml-4">
                    <Sprout className="w-6 h-6" />
                  </div>
                </div>
                <Button 
                  size="sm"
                  className="bg-white/20 hover:bg-white/30 text-white border-0 backdrop-blur-sm"
                >
                  Get Predictions
                  <ArrowRight className="w-4 h-4 ml-2" />
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Secondary Tool Cards */}
        <div className="grid grid-cols-2 gap-4 mb-6">
          {toolCards.slice(1, 3).map((tool) => (
            <Card 
              key={tool.id}
              className="glass-card border-0 cursor-pointer hover:scale-[1.02] transition-all duration-200 organic-shadow"
              onClick={tool.action}
            >
              <CardContent className="p-5">
                <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-primary to-primary/80 flex items-center justify-center mb-4 organic-shadow">
                  <tool.icon className="w-6 h-6 text-white" />
                </div>
                <h3 className="font-medium text-foreground mb-2 leading-tight">
                  {tool.title}
                </h3>
                <p className="text-sm text-muted-foreground leading-relaxed">
                  {tool.description}
                </p>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* AI Assistant Card */}
        <Card 
          className="glass-card border-0 cursor-pointer hover:scale-[1.01] transition-all duration-200 organic-shadow"
          onClick={() => onNavigate('chatbot')}
        >
          <CardContent className="p-5">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-primary to-primary/80 flex items-center justify-center organic-shadow">
                <MessageCircle className="w-6 h-6 text-white" />
              </div>
              <div className="flex-1">
                <h3 className="font-medium text-foreground mb-1">
                  AI Kisan Assistant
                </h3>
                <p className="text-sm text-muted-foreground">
                  Chat with farming expert AI for personalized advice
                </p>
              </div>
              <ArrowRight className="w-5 h-5 text-muted-foreground" />
            </div>
          </CardContent>
        </Card>

        {/* Quick Actions */}
        <div className="mt-8 pt-6 border-t border-border/50">
          <p className="text-sm text-muted-foreground text-center mb-4">
            Need help getting started? Our AI is here to guide you through every step.
          </p>
          <div className="flex gap-3">
            <Button 
              variant="outline" 
              className="flex-1 h-12 glass-button border-border/50 hover:bg-primary/5"
              onClick={() => onNavigate('profile')}
            >
              <Leaf className="w-4 h-4 mr-2" />
              Settings
            </Button>
            <Button 
              className="flex-1 h-12 cta-glow"
              style={{ backgroundColor: 'var(--cta)', color: 'var(--cta-foreground)' }}
              onClick={() => onNavigate('chatbot')}
            >
              <MessageCircle className="w-4 h-4 mr-2" />
              Ask AI
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}