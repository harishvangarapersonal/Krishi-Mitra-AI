import { ArrowLeft, TrendingUp, Leaf, Droplets } from 'lucide-react';
import { Card, CardContent } from './ui/card';
import { ImageWithFallback } from './figma/ImageWithFallback';

interface RecommendationsPageProps {
  onNavigate: (screen: string) => void;
}

const cropData = [
  {
    id: 1,
    name: 'Maize',
    englishName: 'Maize',
    image: 'https://images.unsplash.com/photo-1657520832269-cea57052ec7b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxpbmRpYW4lMjBmYXJtZXIlMjBjcm9wcyUyMG1haXplfGVufDF8fHx8MTc1ODA0OTI0Mnww&ixlib=rb-4.1.0&q=80&w=1080',
    yield: '2.5 tons/hectare',
    profit: '₹35,000',
    sustainabilityScore: 85,
    profitValue: 35000
  },
  {
    id: 2,
    name: 'Wheat',
    englishName: 'Wheat',
    image: 'https://images.unsplash.com/photo-1659270102240-13679a7e29b2?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx3aGVhdCUyMGNyb3AlMjBmaWVsZCUyMGdvbGRlbnxlbnwxfHx8fDE3NTc5NjMwNTd8MA&ixlib=rb-4.1.0&q=80&w=1080',
    yield: '3.2 tons/hectare',
    profit: '₹28,000',
    sustainabilityScore: 75,
    profitValue: 28000
  },
  {
    id: 3,
    name: 'Rice',
    englishName: 'Rice',
    image: 'https://images.unsplash.com/photo-1655903724829-37b3cd3d4ab9?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxyaWNlJTIwcGFkZHklMjBmaWVsZCUyMGdyZWVufGVufDF8fHx8MTc1ODA0OTI0N3ww&ixlib=rb-4.1.0&q=80&w=1080',
    yield: '4.1 tons/hectare',
    profit: '₹32,000',
    sustainabilityScore: 70,
    profitValue: 32000
  }
];

function SustainabilityGauge({ score }: { score: number }) {
  const radius = 24;
  const strokeWidth = 4;
  const normalizedRadius = radius - strokeWidth * 2;
  const circumference = normalizedRadius * 2 * Math.PI;
  const strokeDasharray = `${(score / 100) * circumference} ${circumference}`;
  
  return (
    <div className="relative w-14 h-14">
      <svg className="w-full h-full transform -rotate-90" viewBox={`0 0 ${radius * 2} ${radius * 2}`}>
        <circle
          cx={radius}
          cy={radius}
          r={normalizedRadius}
          stroke="#e5e5e5"
          strokeWidth={strokeWidth}
          fill="transparent"
        />
        <circle
          cx={radius}
          cy={radius}
          r={normalizedRadius}
          stroke="#00C9A7"
          strokeWidth={strokeWidth}
          strokeDasharray={strokeDasharray}
          strokeLinecap="round"
          fill="transparent"
        />
      </svg>
      <div className="absolute inset-0 flex items-center justify-center">
        <span className="text-xs text-foreground">{score}</span>
      </div>
    </div>
  );
}

export function RecommendationsPage({ onNavigate }: RecommendationsPageProps) {
  const maxProfit = Math.max(...cropData.map(crop => crop.profitValue));
  
  return (
    <div className="min-h-screen bg-background pb-20">
      {/* Header */}
      <div className="bg-white shadow-sm p-4 flex items-center gap-4">
        <button 
          onClick={() => onNavigate('home')}
          className="w-10 h-10 rounded-full bg-gray-100 flex items-center justify-center hover:bg-gray-200 transition-colors"
        >
          <ArrowLeft className="w-5 h-5 text-foreground" />
        </button>
        <div>
          <h1 className="text-xl text-foreground">Your Top 3 Recommendations</h1>
          <p className="text-sm text-muted-foreground">AI-powered crop suggestions</p>
        </div>
      </div>

      {/* Profit Comparison Chart */}
      <div className="p-4">
        <Card className="shadow-lg border-0 bg-white mb-6">
          <CardContent className="p-6">
            <div className="flex items-center gap-2 mb-4">
              <TrendingUp className="w-5 h-5 text-accent" />
              <h2 className="text-lg text-foreground">Estimated Profit Comparison</h2>
            </div>
            <div className="space-y-3">
              {cropData.map((crop) => (
                <div key={crop.id} className="flex items-center gap-3">
                  <div className="w-16 text-sm text-foreground">{crop.englishName}</div>
                  <div className="flex-1 bg-gray-100 rounded-full h-3 overflow-hidden">
                    <div 
                      className="h-full bg-gradient-to-r from-accent to-accent/80 rounded-full transition-all duration-500"
                      style={{ width: `${(crop.profitValue / maxProfit) * 100}%` }}
                    />
                  </div>
                  <div className="w-20 text-sm text-foreground text-right">{crop.profit}</div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Crop Details Cards */}
        <div className="space-y-4">
          {cropData.map((crop) => (
            <Card key={crop.id} className="shadow-lg border-0 bg-white overflow-hidden">
              <div className="relative h-48">
                <ImageWithFallback 
                  src={crop.image}
                  alt={crop.name}
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent" />
                <div className="absolute bottom-4 left-4">
                  <h2 className="text-2xl text-white mb-1">{crop.name}</h2>
                  <p className="text-white/80 text-sm">{crop.englishName}</p>
                </div>
                <div className="absolute top-4 right-4">
                  <SustainabilityGauge score={crop.sustainabilityScore} />
                </div>
              </div>
              
              <CardContent className="p-6">
                <div className="grid grid-cols-2 gap-6">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
                      <Leaf className="w-5 h-5 text-primary" />
                    </div>
                    <div>
                      <p className="text-xs text-muted-foreground mb-1">Yield Prediction</p>
                      <p className="text-sm text-foreground">{crop.yield}</p>
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-lg bg-accent/10 flex items-center justify-center">
                      <TrendingUp className="w-5 h-5 text-accent" />
                    </div>
                    <div>
                      <p className="text-xs text-muted-foreground mb-1">Profit Estimate</p>
                      <p className="text-sm text-foreground">{crop.profit} / hectare</p>
                    </div>
                  </div>
                </div>
                
                <div className="mt-4 pt-4 border-t border-border/50">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Droplets className="w-4 h-4 text-primary" />
                      <span className="text-sm text-foreground">Sustainability Score</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="text-sm text-foreground">{crop.sustainabilityScore}/100</span>
                      <div className="w-2 h-2 rounded-full bg-accent"></div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
}