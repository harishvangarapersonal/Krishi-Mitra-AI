import { useState, useEffect } from 'react';
import { ArrowLeft, TrendingUp, Sprout, DollarSign, Droplets, Info, Award } from 'lucide-react';
import { useRecommendations } from '../hooks/useRecommendations';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Progress } from './ui/progress';
import { BarChart, Bar, XAxis, YAxis, ResponsiveContainer, Cell, PieChart, Pie } from 'recharts';

interface UnifiedResultsPageProps {
  onNavigate: (screen: string) => void;
}

export function UnifiedResultsPage({ onNavigate }: UnifiedResultsPageProps) {
  const { recommendations } = useRecommendations();
  const [activeTab, setActiveTab] = useState('');
  const [cropData, setCropData] = useState<any[]>([]);

  useEffect(() => {
    if (recommendations.length > 0) {
      const latestRecommendation = recommendations[0];
      const crops = latestRecommendation.recommendations.map((rec: any, index: number) => ({
        id: rec.crop.toLowerCase().replace(/[^a-z0-9]/g, '-'),
        name: rec.crop.split(' ')[0], // First word for tab
        fullName: rec.crop,
        profit: Math.round((rec.profit_estimate.min + rec.profit_estimate.max) / 2),
        profitRange: `₹${rec.profit_estimate.min.toLocaleString()} - ₹${rec.profit_estimate.max.toLocaleString()}`,
        yield: rec.yield_estimate,
        sustainability: rec.sustainability_score,
        remarks: rec.remarks
      }));
      
      setCropData(crops);
      if (crops.length > 0) {
        setActiveTab(crops[0].id);
      }
    } else {
      // Fallback to mock data if no recommendations
      const mockData = [
        {
          id: 'bajra',
          name: 'Bajra',
          fullName: 'Bajra (Pearl Millet)',
          profit: 28000,
          profitRange: '₹25,000 - ₹30,000',
          yield: '1.5 - 2.0 tons/hectare',
          sustainability: 92,
          remarks: 'Low water use, improves soil health'
        },
        {
          id: 'maize',
          name: 'Maize',
          fullName: 'Maize',
          profit: 25000,
          profitRange: '₹22,000 - ₹27,000',
          yield: '2.2 - 2.8 tons/hectare',
          sustainability: 78,
          remarks: 'Good market demand, moderate water requirement'
        },
        {
          id: 'cotton',
          name: 'Cotton',
          fullName: 'Cotton',
          profit: 22000,
          profitRange: '₹20,000 - ₹25,000',
          yield: '1.8 - 2.3 tons/hectare',
          sustainability: 65,
          remarks: 'High profit potential, requires careful management'
        }
      ];
      setCropData(mockData);
      setActiveTab('bajra');
    }
  }, [recommendations]);

  const chartData = cropData.map(crop => ({
    name: crop.name,
    profit: crop.profit
  }));

  const activeCrop = cropData.find(crop => crop.id === activeTab) || cropData[0];

  // Create gauge data for sustainability
  const gaugeData = [
    { name: 'Score', value: activeCrop.sustainability, fill: '#388E3C' },
    { name: 'Remaining', value: 100 - activeCrop.sustainability, fill: '#E0E0E0' }
  ];

  return (
    <div className="min-h-screen bg-background pb-20">
      {/* Header */}
      <div className="sticky top-0 bg-background/90 backdrop-blur-md border-b border-border z-10">
        <div className="flex items-center justify-between px-6 py-4">
          <div className="flex items-center gap-3">
            <Button 
              variant="ghost" 
              size="sm"
              onClick={() => onNavigate('farmer-input')}
              className="p-2"
            >
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <div>
              <h1 className="font-medium text-foreground text-xl">Final Predictions</h1>
              <p className="text-xs text-muted-foreground">AI analysis complete</p>
            </div>
          </div>
          <Award className="w-6 h-6 text-primary" />
        </div>
      </div>

      <div className="px-6 py-6 space-y-6">
        {/* Profit Comparison Chart */}
        <Card className="glass-card border-0 organic-shadow">
          <CardHeader className="pb-4">
            <CardTitle className="flex items-center gap-2 text-lg">
              <TrendingUp className="w-5 h-5 text-primary" />
              Estimated Profit Comparison (per hectare)
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-48">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={chartData} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
                  <XAxis 
                    dataKey="name" 
                    axisLine={false}
                    tickLine={false}
                    tick={{ fontSize: 12, fill: '#2E7D33' }}
                  />
                  <YAxis 
                    axisLine={false}
                    tickLine={false}
                    tick={{ fontSize: 12, fill: '#2E7D33' }}
                    tickFormatter={(value) => `₹${value/1000}k`}
                  />
                  <Bar dataKey="profit" radius={[8, 8, 0, 0]} fill="#FFA726">
                    {chartData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill="#FFA726" />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        {/* Tabbed Crop Details */}
        <Card className="glass-card border-0 organic-shadow">
          <CardContent className="p-0">
            <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
              <TabsList className="grid w-full grid-cols-3 bg-muted/20 rounded-xl m-4 mb-0 h-12">
                {cropData.map((crop) => (
                  <TabsTrigger 
                    key={crop.id}
                    value={crop.id}
                    className="text-sm font-medium data-[state=active]:bg-white data-[state=active]:shadow-sm data-[state=active]:text-primary rounded-lg"
                  >
                    {crop.name}
                  </TabsTrigger>
                ))}
              </TabsList>

              {cropData.map((crop) => (
                <TabsContent key={crop.id} value={crop.id} className="p-6 pt-4">
                  <div className="space-y-4">
                    {/* Crop Header */}
                    <div className="text-center pb-4">
                      <h3 className="text-xl font-medium text-foreground mb-2">
                        {crop.fullName}
                      </h3>
                      <p className="text-muted-foreground">
                        Recommended for your farm conditions
                      </p>
                    </div>

                    {/* Prediction Table */}
                    <div className="space-y-3">
                      {/* Crop Row */}
                      <div className="flex items-center gap-4 p-4 bg-muted/10 rounded-xl border border-border/30">
                        <div className="w-10 h-10 rounded-lg bg-primary/15 flex items-center justify-center">
                          <Sprout className="w-5 h-5 text-primary" />
                        </div>
                        <div className="flex-1">
                          <p className="font-medium text-foreground">🌱 Crop</p>
                        </div>
                        <p className="font-medium text-foreground">{crop.fullName}</p>
                      </div>

                      {/* Yield Row */}
                      <div className="flex items-center gap-4 p-4 bg-muted/10 rounded-xl border border-border/30">
                        <div className="w-10 h-10 rounded-lg bg-primary/15 flex items-center justify-center">
                          <TrendingUp className="w-5 h-5 text-primary" />
                        </div>
                        <div className="flex-1">
                          <p className="font-medium text-foreground">📈 Yield</p>
                        </div>
                        <p className="font-medium text-foreground">{crop.yield}</p>
                      </div>

                      {/* Profit Row */}
                      <div className="flex items-center gap-4 p-4 bg-muted/10 rounded-xl border border-border/30">
                        <div className="w-10 h-10 rounded-lg bg-orange-100 flex items-center justify-center">
                          <DollarSign className="w-5 h-5 text-orange-600" />
                        </div>
                        <div className="flex-1">
                          <p className="font-medium text-foreground">💰 Profit</p>
                        </div>
                        <p className="font-medium text-foreground">
                          Est. {crop.profitRange} per hectare
                        </p>
                      </div>

                      {/* Sustainability Row with Gauge */}
                      <div className="flex items-center gap-4 p-4 bg-muted/10 rounded-xl border border-border/30">
                        <div className="w-10 h-10 rounded-lg bg-blue-100 flex items-center justify-center">
                          <Droplets className="w-5 h-5 text-blue-600" />
                        </div>
                        <div className="flex-1">
                          <p className="font-medium text-foreground mb-2">🌍 Sustainability</p>
                          <div className="flex items-center gap-3">
                            {/* Semi-circle gauge chart */}
                            <div className="w-16 h-8 relative">
                              <ResponsiveContainer width="100%" height="100%">
                                <PieChart>
                                  <Pie
                                    data={gaugeData}
                                    cx="50%"
                                    cy="100%"
                                    startAngle={180}
                                    endAngle={0}
                                    innerRadius={20}
                                    outerRadius={30}
                                    paddingAngle={0}
                                    dataKey="value"
                                  />
                                </PieChart>
                              </ResponsiveContainer>
                              <div className="absolute bottom-0 left-1/2 transform -translate-x-1/2 text-xs font-medium text-primary">
                                {crop.sustainability}
                              </div>
                            </div>
                            <span className="text-sm text-muted-foreground">/100</span>
                          </div>
                        </div>
                        <p className="font-medium text-primary">{crop.sustainability}/100</p>
                      </div>

                      {/* Remarks Row */}
                      <div className="flex items-start gap-4 p-4 bg-muted/10 rounded-xl border border-border/30">
                        <div className="w-10 h-10 rounded-lg bg-orange-100 flex items-center justify-center">
                          <Info className="w-5 h-5 text-orange-600" />
                        </div>
                        <div className="flex-1">
                          <p className="font-medium text-foreground mb-2">ℹ️ Remarks</p>
                          <p className="text-muted-foreground leading-relaxed">{crop.remarks}</p>
                        </div>
                      </div>
                    </div>
                  </div>
                </TabsContent>
              ))}
            </Tabs>
          </CardContent>
        </Card>

        {/* Action Buttons */}
        <div className="grid grid-cols-2 gap-4">
          <Button
            variant="outline"
            onClick={() => onNavigate('farmer-input')}
            className="h-14 glass-button border-border/50 hover:bg-primary/5"
          >
            <TrendingUp className="w-5 h-5 mr-2" />
            Try Different Input
          </Button>
          <Button
            onClick={() => onNavigate('home')}
            className="h-14 cta-glow"
            style={{ backgroundColor: 'var(--cta)', color: 'var(--cta-foreground)' }}
          >
            <Award className="w-5 h-5 mr-2" />
            Save Results
          </Button>
        </div>

        {/* Additional Info */}
        <div className="p-5 bg-primary/5 rounded-xl border border-primary/20">
          <p className="text-sm text-foreground leading-relaxed text-center">
            These recommendations are based on your location, soil type, weather patterns, 
            and current market conditions. Results may vary based on actual farming practices.
          </p>
        </div>
      </div>
    </div>
  );
}