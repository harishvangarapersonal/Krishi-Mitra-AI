import { useState, useEffect } from 'react';
import { ArrowLeft, MapPin, CheckCircle, Droplet, Sprout, Settings } from 'lucide-react';
import { useAuth } from '../hooks/useAuth';
import { useFarms } from '../hooks/useFarms';
import { useRecommendations } from '../hooks/useRecommendations';
import { toast } from 'sonner@2.0.3';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';

interface FarmerInputPageProps {
  onNavigate: (screen: string) => void;
}

export function FarmerInputPage({ onNavigate }: FarmerInputPageProps) {
  const { user, profile } = useAuth();
  const { farms, createFarm } = useFarms();
  const { generateRecommendations } = useRecommendations();
  
  const [farmSize, setFarmSize] = useState('');
  const [unit, setUnit] = useState('acres');
  const [irrigationSource, setIrrigationSource] = useState('');
  const [previousCrop, setPreviousCrop] = useState('');
  const [selectedState, setSelectedState] = useState('');
  const [selectedDistrict, setSelectedDistrict] = useState('');
  const [showDemoMode, setShowDemoMode] = useState(false);
  const [loading, setLoading] = useState(false);

  // Use user's location from profile as default
  useEffect(() => {
    if (profile?.location) {
      // Try to parse location if it's in "City, State" format
      const locationParts = profile.location.split(', ');
      if (locationParts.length >= 2) {
        const state = locationParts[locationParts.length - 1].toLowerCase();
        if (state.includes('jharkhand')) setSelectedState('jh');
        else if (state.includes('telangana')) setSelectedState('ts');
        else if (state.includes('andhra')) setSelectedState('ap');
      }
    }
  }, [profile]);

  const states = [
    { id: 'ap', name: 'Andhra Pradesh' },
    { id: 'ts', name: 'Telangana' },
    { id: 'jh', name: 'Jharkhand' }
  ];

  const districts = {
    ap: ['Visakhapatnam', 'Vijayawada', 'Guntur', 'Nellore'],
    ts: ['Hyderabad', 'Warangal', 'Nizamabad', 'Karimnagar'],
    jh: ['Ranchi', 'Jamshedpur', 'Dhanbad', 'Bokaro']
  };

  const irrigationOptions = [
    { id: 'rainwater', label: 'Rainwater', icon: '🌧️' },
    { id: 'borewell', label: 'Borewell', icon: '⚡' },
    { id: 'canal', label: 'Canal', icon: '🌊' },
    { id: 'river', label: 'River/Pond', icon: '🏞️' }
  ];

  const cropOptions = [
    'Rice', 'Wheat', 'Maize', 'Cotton', 'Sugarcane', 'Soybean', 
    'Groundnut', 'Bajra', 'Jowar', 'Barley', 'Mustard', 'Sesame'
  ];

  const handleGetPredictions = async () => {
    if (!user) return;
    
    setLoading(true);
    
    try {
      // Create or get farm data
      let farmId = farms[0]?.id; // Use existing farm if available
      
      if (!farmId) {
        // Create new farm
        const newFarm = await createFarm({
          name: 'My Farm',
          size: parseFloat(farmSize),
          size_unit: unit as 'acres' | 'hectares',
          location: {
            state: selectedState || 'jh',
            district: selectedDistrict || 'ranchi',
            latitude: 23.3441, // Mock coordinates for Ranchi
            longitude: 85.3096
          },
          soil_type: 'Clay loam', // Mock soil type
          irrigation_source: irrigationSource as any,
          previous_crop: previousCrop,
          is_active: true
        });
        farmId = newFarm.id;
      }

      // Generate recommendations
      const inputData = {
        farmId,
        farmSize: parseFloat(farmSize),
        unit,
        irrigationSource,
        previousCrop,
        location: {
          state: selectedState || 'jh',
          district: selectedDistrict || 'ranchi'
        },
        season: 'current'
      };

      await generateRecommendations(inputData);
      
      toast.success('Crop recommendations generated successfully!');
      onNavigate('unified-results');
      
    } catch (error: any) {
      toast.error(error.message || 'Failed to generate recommendations');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-background pb-20">
      {/* Header */}
      <div className="sticky top-0 bg-background/90 backdrop-blur-md border-b border-border z-10">
        <div className="flex items-center justify-between px-6 py-4">
          <div className="flex items-center gap-3">
            <Button 
              variant="ghost" 
              size="sm"
              onClick={() => onNavigate('home')}
              className="p-2"
            >
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <div>
              <h1 className="font-medium text-foreground">Farm Analysis</h1>
              <p className="text-xs text-muted-foreground">Get personalized crop recommendations</p>
            </div>
          </div>
        </div>
      </div>

      <div className="px-6 py-6 space-y-6">
        {/* Automated Data Confirmation */}
        <Card className="glass-card border-0 organic-shadow">
          <CardHeader className="pb-4">
            <CardTitle className="flex items-center gap-2 text-lg">
              <MapPin className="w-5 h-5 text-primary" />
              Location Verified
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {/* Map Placeholder */}
            <div className="h-36 bg-gradient-to-br from-primary/8 to-primary/4 rounded-xl flex items-center justify-center border border-border/30 relative overflow-hidden">
              <div className="absolute inset-0 opacity-30" style={{
                backgroundImage: `url("data:image/svg+xml,%3Csvg width='40' height='40' viewBox='0 0 40 40' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23388E3C' fill-opacity='0.05'%3E%3Ccircle cx='3' cy='3' r='3'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`
              }}></div>
              <div className="text-center relative z-10">
                <div className="w-12 h-12 rounded-full bg-primary/15 flex items-center justify-center mx-auto mb-3">
                  <MapPin className="w-6 h-6 text-primary" />
                </div>
                <p className="font-medium text-foreground">Jharkhand, India</p>
                <p className="text-sm text-muted-foreground">Location automatically detected</p>
              </div>
            </div>

            {/* Status Indicators */}
            <div className="grid grid-cols-2 gap-3">
              <div className="flex items-center gap-3 p-4 bg-green-50 rounded-xl border border-green-100">
                <CheckCircle className="w-5 h-5 text-green-600" />
                <div>
                  <p className="font-medium text-green-900">Location Verified</p>
                  <p className="text-xs text-green-700">GPS coordinates confirmed</p>
                </div>
              </div>
              <div className="flex items-center gap-3 p-4 bg-blue-50 rounded-xl border border-blue-100">
                <CheckCircle className="w-5 h-5 text-blue-600" />
                <div>
                  <p className="font-medium text-blue-900">Soil & Weather Data Fetched</p>
                  <p className="text-xs text-blue-700">Clay loam, monsoon season</p>
                </div>
              </div>
            </div>

            {/* Demo Mode Toggle */}
            <Dialog open={showDemoMode} onOpenChange={setShowDemoMode}>
              <DialogTrigger asChild>
                <Button 
                  variant="outline" 
                  size="sm"
                  className="w-full h-10 glass-button border-border/50 text-muted-foreground hover:text-foreground"
                >
                  <Settings className="w-4 h-4 mr-2" />
                  Change Location (For Demo)
                </Button>
              </DialogTrigger>
              <DialogContent className="glass-card border-0">
                <DialogHeader>
                  <DialogTitle className="flex items-center gap-2">
                    <MapPin className="w-5 h-5 text-primary" />
                    Demo Location Settings
                  </DialogTitle>
                </DialogHeader>
                <div className="space-y-4 pt-4">
                  <div className="space-y-2">
                    <Label>Select State</Label>
                    <Select value={selectedState} onValueChange={setSelectedState}>
                      <SelectTrigger className="glass-button border-border/50">
                        <SelectValue placeholder="Choose state" />
                      </SelectTrigger>
                      <SelectContent>
                        {states.map((state) => (
                          <SelectItem key={state.id} value={state.id}>
                            {state.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  
                  {selectedState && (
                    <div className="space-y-2">
                      <Label>Select District</Label>
                      <Select value={selectedDistrict} onValueChange={setSelectedDistrict}>
                        <SelectTrigger className="glass-button border-border/50">
                          <SelectValue placeholder="Choose district" />
                        </SelectTrigger>
                        <SelectContent>
                          {districts[selectedState as keyof typeof districts]?.map((district) => (
                            <SelectItem key={district} value={district.toLowerCase()}>
                              {district}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  )}
                  
                  <Button 
                    onClick={() => setShowDemoMode(false)}
                    className="w-full h-12 cta-glow"
                    style={{ backgroundColor: 'var(--cta)', color: 'var(--cta-foreground)' }}
                    disabled={!selectedState || !selectedDistrict}
                  >
                    Update Location
                  </Button>
                </div>
              </DialogContent>
            </Dialog>
          </CardContent>
        </Card>

        {/* Manual Farmer Inputs */}
        <Card className="glass-card border-0 organic-shadow">
          <CardHeader className="pb-4">
            <CardTitle className="flex items-center gap-2 text-lg">
              <Sprout className="w-5 h-5 text-primary" />
              Your Farm Details
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* Farm Size */}
            <div className="space-y-3">
              <Label className="font-medium text-foreground">Farm Size</Label>
              <div className="flex gap-3">
                <Input
                  type="number"
                  placeholder="Enter size"
                  value={farmSize}
                  onChange={(e) => setFarmSize(e.target.value)}
                  className="glass-button border-border/50 bg-input"
                />
                <Select value={unit} onValueChange={setUnit}>
                  <SelectTrigger className="w-28 glass-button border-border/50 bg-input">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="acres">Acres</SelectItem>
                    <SelectItem value="hectares">Hectares</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            {/* Irrigation Source */}
            <div className="space-y-3">
              <Label className="font-medium text-foreground">Irrigation Source</Label>
              <div className="grid grid-cols-2 gap-3">
                {irrigationOptions.map((option) => (
                  <button
                    key={option.id}
                    onClick={() => setIrrigationSource(option.id)}
                    className={`p-4 rounded-xl border-2 transition-all duration-200 ${
                      irrigationSource === option.id
                        ? 'border-primary bg-primary/10 glass-card'
                        : 'border-border/50 bg-card hover:border-primary/50 glass-card'
                    }`}
                  >
                    <div className="text-2xl mb-2">{option.icon}</div>
                    <p className="font-medium text-foreground text-sm">{option.label}</p>
                  </button>
                ))}
              </div>
            </div>

            {/* Previous Crop */}
            <div className="space-y-3">
              <Label className="font-medium text-foreground">Previous Season's Crop</Label>
              <Select value={previousCrop} onValueChange={setPreviousCrop}>
                <SelectTrigger className="glass-button border-border/50 bg-input">
                  <SelectValue placeholder="Select previous crop" />
                </SelectTrigger>
                <SelectContent>
                  {cropOptions.map((crop) => (
                    <SelectItem key={crop} value={crop.toLowerCase()}>
                      {crop}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>

        {/* Get Predictions Button */}
        <Button
          onClick={handleGetPredictions}
          disabled={!farmSize || !irrigationSource || !previousCrop || loading}
          className="w-full h-16 text-lg font-medium cta-glow disabled:opacity-50 disabled:cursor-not-allowed"
          style={{ backgroundColor: 'var(--cta)', color: 'var(--cta-foreground)' }}
        >
          <div className="flex items-center gap-3">
            <Sprout className="w-6 h-6" />
            <span>{loading ? 'Generating...' : 'Get Predictions'}</span>
          </div>
        </Button>

        {/* Help Text */}
        <div className="p-4 bg-primary/5 rounded-xl border border-primary/20">
          <p className="text-sm text-foreground leading-relaxed text-center">
            Our AI will analyze your farm data along with soil conditions, weather patterns, 
            and market trends to provide personalized crop recommendations with profit insights.
          </p>
        </div>
      </div>
    </div>
  );
}