import { useState } from 'react';
import { ArrowLeft, TrendingUp, Calendar, Thermometer, Droplets, Target } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { LineChart, Line, XAxis, YAxis, ResponsiveContainer, Area, AreaChart } from 'recharts';

interface YieldForecastPageProps {
  onNavigate: (screen: string) => void;
}

export function YieldForecastPage({ onNavigate }: YieldForecastPageProps) {
  const [selectedCrop, setSelectedCrop] = useState('');
  const [farmSize, setFarmSize] = useState('');
  const [showForecast, setShowForecast] = useState(false);

  const crops = ['Bajra', 'Maize', 'Rice', 'Wheat', 'Cotton', 'Soybean'];

  const forecastData = [
    { month: 'Month 1', yield: 0, optimal: 0 },
    { month: 'Month 2', yield: 15, optimal: 20 },
    { month: 'Month 3', yield: 45, optimal: 50 },
    { month: 'Month 4', yield: 75, optimal: 80 },
    { month: 'Month 5', yield: 95, optimal: 100 },
    { month: 'Harvest', yield: 100, optimal: 100 },
  ];

  const handleForecast = () => {
    if (selectedCrop && farmSize) {
      setShowForecast(true);
    }
  };

  return (
    <div className="min-h-screen bg-background pb-20">
      {/* Header */}
      <div className="sticky top-0 bg-background/80 backdrop-blur-md border-b border-border z-10">
        <div className="flex items-center justify-between px-6 py-4">
          <div className="flex items-center gap-3">
            <Button 
              variant="ghost" 
              size="sm"
              onClick={() => onNavigate('home')}
              className="p-2"
            >
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <div>
              <h1 className="font-medium text-foreground">Yield Forecaster</h1>
              <p className="text-xs text-muted-foreground">Predict harvest quantities</p>
            </div>
          </div>
          <TrendingUp className="w-6 h-6 text-accent" />
        </div>
      </div>

      <div className="px-6 py-6 space-y-6">
        {!showForecast ? (
          <>
            {/* Input Form */}
            <Card className="glass-card border-0">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Target className="w-5 h-5 text-primary" />
                  Forecast Parameters
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label>Select Crop</Label>
                  <Select value={selectedCrop} onValueChange={setSelectedCrop}>
                    <SelectTrigger className="glass-button border-border/50 bg-input">
                      <SelectValue placeholder="Choose crop to forecast" />
                    </SelectTrigger>
                    <SelectContent>
                      {crops.map((crop) => (
                        <SelectItem key={crop} value={crop.toLowerCase()}>
                          {crop}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label>Farm Size (hectares)</Label>
                  <Input
                    type="number"
                    placeholder="Enter farm size"
                    value={farmSize}
                    onChange={(e) => setFarmSize(e.target.value)}
                    className="glass-button border-border/50 bg-input"
                  />
                </div>
              </CardContent>
            </Card>

            {/* Current Conditions */}
            <Card className="glass-card border-0">
              <CardHeader>
                <CardTitle className="text-lg">Current Growing Conditions</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-3 gap-4">
                  <div className="text-center p-3 bg-muted/20 rounded-lg">
                    <Calendar className="w-6 h-6 text-primary mx-auto mb-2" />
                    <p className="text-sm font-medium">Season</p>
                    <p className="text-xs text-muted-foreground">Kharif</p>
                  </div>
                  <div className="text-center p-3 bg-muted/20 rounded-lg">
                    <Thermometer className="w-6 h-6 text-orange-500 mx-auto mb-2" />
                    <p className="text-sm font-medium">Temp</p>
                    <p className="text-xs text-muted-foreground">28°C avg</p>
                  </div>
                  <div className="text-center p-3 bg-muted/20 rounded-lg">
                    <Droplets className="w-6 h-6 text-blue-500 mx-auto mb-2" />
                    <p className="text-sm font-medium">Rainfall</p>
                    <p className="text-xs text-muted-foreground">750mm exp</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Button
              onClick={handleForecast}
              disabled={!selectedCrop || !farmSize}
              className="w-full h-14 bg-gradient-to-r from-accent to-accent/90 hover:from-accent/90 hover:to-accent text-white glass-button disabled:opacity-50"
            >
              Generate Yield Forecast
            </Button>
          </>
        ) : (
          <>
            {/* Forecast Results */}
            <Card className="glass-card border-0">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <TrendingUp className="w-5 h-5 text-accent" />
                  Yield Forecast - {selectedCrop}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-48 mb-4">
                  <ResponsiveContainer width="100%" height="100%">
                    <AreaChart data={forecastData}>
                      <XAxis 
                        dataKey="month" 
                        axisLine={false}
                        tickLine={false}
                        tick={{ fontSize: 12, fill: '#004D40' }}
                      />
                      <YAxis 
                        axisLine={false}
                        tickLine={false}
                        tick={{ fontSize: 12, fill: '#004D40' }}
                        tickFormatter={(value) => `${value}%`}
                      />
                      <Area
                        type="monotone"
                        dataKey="optimal"
                        stroke="#004D40"
                        fill="#004D40"
                        fillOpacity={0.1}
                        strokeDasharray="5 5"
                      />
                      <Area
                        type="monotone"
                        dataKey="yield"
                        stroke="#26A69A"
                        fill="#26A69A"
                        fillOpacity={0.3}
                      />
                    </AreaChart>
                  </ResponsiveContainer>
                </div>
                <div className="flex items-center gap-4 text-xs">
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 bg-accent rounded-full"></div>
                    <span>Predicted Yield</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 border-2 border-primary rounded-full"></div>
                    <span>Optimal Yield</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Yield Summary */}
            <Card className="glass-card border-0">
              <CardHeader>
                <CardTitle>Expected Results</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 gap-4">
                  <div className="text-center p-4 bg-accent/10 rounded-lg">
                    <p className="text-2xl font-medium text-accent">2.1</p>
                    <p className="text-sm text-muted-foreground">Tons/hectare</p>
                  </div>
                  <div className="text-center p-4 bg-primary/10 rounded-lg">
                    <p className="text-2xl font-medium text-primary">{(parseFloat(farmSize) * 2.1).toFixed(1)}</p>
                    <p className="text-sm text-muted-foreground">Total tons</p>
                  </div>
                </div>
                <div className="mt-4 p-3 bg-muted/20 rounded-lg">
                  <p className="text-sm text-foreground font-medium mb-1">Recommendations:</p>
                  <p className="text-xs text-muted-foreground">
                    Based on current conditions, expect moderate yield. Consider organic fertilizers 
                    in month 3 for optimal growth.
                  </p>
                </div>
              </CardContent>
            </Card>

            <div className="grid grid-cols-2 gap-3">
              <Button
                variant="outline"
                onClick={() => setShowForecast(false)}
                className="h-12 glass-button border-border/50"
              >
                New Forecast
              </Button>
              <Button
                onClick={() => onNavigate('home')}
                className="h-12 bg-gradient-to-r from-primary to-primary/90 text-white glass-button"
              >
                Save Forecast
              </Button>
            </div>
          </>
        )}
      </div>
    </div>
  );
}