import { useState } from 'react';
import { ArrowLeft, Camera, Upload, CheckCircle, AlertTriangle, Leaf } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';

interface DiseaseScanPageProps {
  onNavigate: (screen: string) => void;
}

export function DiseaseScanPage({ onNavigate }: DiseaseScanPageProps) {
  const [isScanning, setIsScanning] = useState(false);
  const [scanResult, setScanResult] = useState<any>(null);

  const handleScan = () => {
    setIsScanning(true);
    // Simulate AI analysis
    setTimeout(() => {
      setIsScanning(false);
      setScanResult({
        disease: 'Leaf Blight',
        hindiName: 'Leaf Blight Disease',
        confidence: 92,
        severity: 'Medium',
        treatment: 'Apply fungicide spray twice weekly',
        prevention: 'Ensure proper drainage and air circulation'
      });
    }, 3000);
  };

  return (
    <div className="min-h-screen bg-background pb-20">
      {/* Header */}
      <div className="sticky top-0 bg-background/80 backdrop-blur-md border-b border-border z-10">
        <div className="flex items-center justify-between px-6 py-4">
          <div className="flex items-center gap-3">
            <Button 
              variant="ghost" 
              size="sm"
              onClick={() => onNavigate('home')}
              className="p-2"
            >
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <div>
              <h1 className="font-medium text-foreground">Crop Disease Scan</h1>
              <p className="text-xs text-muted-foreground">AI-powered disease detection</p>
            </div>
          </div>
          <Camera className="w-6 h-6 text-accent" />
        </div>
      </div>

      <div className="px-6 py-6 space-y-6">
        {!scanResult ? (
          <>
            {/* Camera Interface */}
            <Card className="glass-card border-0 overflow-hidden">
              <div className="relative h-80 bg-gradient-to-br from-accent/5 to-primary/5 flex items-center justify-center">
                {isScanning ? (
                  <div className="text-center">
                    <div className="w-16 h-16 border-4 border-accent border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
                    <p className="text-foreground font-medium">AI is analyzing...</p>
                    <p className="text-sm text-muted-foreground">Analyzing your leaf sample</p>
                  </div>
                ) : (
                  <div className="text-center">
                    <div className="w-20 h-20 rounded-full bg-accent/10 flex items-center justify-center mx-auto mb-4">
                      <Camera className="w-10 h-10 text-accent" />
                    </div>
                    <p className="text-foreground font-medium mb-2">Place the leaf in the center</p>
                    <p className="text-sm text-muted-foreground">Take a clear photo for analysis</p>
                  </div>
                )}
                
                {/* Camera viewfinder overlay */}
                <div className="absolute inset-6 border-2 border-dashed border-accent/50 rounded-lg"></div>
                <div className="absolute top-1/2 left-1/2 w-4 h-4 border-2 border-accent transform -translate-x-1/2 -translate-y-1/2"></div>
              </div>
            </Card>

            {/* Instructions Card */}
            <Card className="glass-card border-0">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Leaf className="w-5 h-5 text-primary" />
                  Scanning Instructions
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-3">
                  <div className="flex items-start gap-3">
                    <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0">
                      <span className="text-sm font-medium text-primary">1</span>
                    </div>
                    <div>
                      <p className="text-sm font-medium text-foreground">Clear Lighting</p>
                      <p className="text-xs text-muted-foreground">Take photo in natural daylight</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-3">
                    <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0">
                      <span className="text-sm font-medium text-primary">2</span>
                    </div>
                    <div>
                      <p className="text-sm font-medium text-foreground">Full Leaf Visible</p>
                      <p className="text-xs text-muted-foreground">Entire leaf should be in frame</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-3">
                    <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0">
                      <span className="text-sm font-medium text-primary">3</span>
                    </div>
                    <div>
                      <p className="text-sm font-medium text-foreground">Focus on Symptoms</p>
                      <p className="text-xs text-muted-foreground">Diseased area clearly visible</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Action Buttons */}
            <div className="space-y-3">
              <Button 
                onClick={handleScan}
                disabled={isScanning}
                className="w-full h-14 bg-gradient-to-r from-accent to-accent/90 hover:from-accent/90 hover:to-accent text-white glass-button disabled:opacity-50"
              >
                <Camera className="w-5 h-5 mr-2" />
                {isScanning ? 'Scanning...' : 'Scan for Disease'}
              </Button>
              
              <Button 
                variant="outline"
                className="w-full h-12 glass-button border-border/50 hover:bg-muted/20"
              >
                <Upload className="w-5 h-5 mr-2" />
                Choose from Gallery
              </Button>
            </div>
          </>
        ) : (
          /* Scan Results */
          <div className="space-y-6">
            {/* Result Header */}
            <Card className="glass-card border-0">
              <CardContent className="p-6">
                <div className="flex items-center gap-4 mb-6">
                  <div className="w-12 h-12 rounded-full bg-orange-100 flex items-center justify-center">
                    <AlertTriangle className="w-6 h-6 text-orange-600" />
                  </div>
                  <div className="flex-1">
                    <h2 className="text-lg font-medium text-foreground">{scanResult.disease}</h2>
                    <p className="text-sm text-muted-foreground">Disease detected</p>
                  </div>
                </div>
                
                <div className="grid grid-cols-2 gap-4">
                  <div className="text-center p-4 bg-accent/10 rounded-lg">
                    <p className="text-2xl font-medium text-accent mb-1">{scanResult.confidence}%</p>
                    <p className="text-xs text-muted-foreground">Confidence</p>
                  </div>
                  <div className="text-center p-4 bg-orange-50 rounded-lg">
                    <p className="text-lg font-medium text-orange-600 mb-1">{scanResult.severity}</p>
                    <p className="text-xs text-muted-foreground">Severity</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Treatment Card */}
            <Card className="glass-card border-0">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <CheckCircle className="w-5 h-5 text-primary" />
                  Treatment Recommendations
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="p-4 bg-primary/5 rounded-lg border border-primary/20">
                  <p className="text-sm font-medium text-foreground mb-2">Immediate Treatment:</p>
                  <p className="text-sm text-foreground">{scanResult.treatment}</p>
                </div>
                <div className="p-4 bg-accent/5 rounded-lg border border-accent/20">
                  <p className="text-sm font-medium text-foreground mb-2">Future Prevention:</p>
                  <p className="text-sm text-foreground">{scanResult.prevention}</p>
                </div>
              </CardContent>
            </Card>

            {/* Action Buttons */}
            <div className="grid grid-cols-2 gap-3">
              <Button 
                onClick={() => setScanResult(null)}
                variant="outline"
                className="h-12 glass-button border-border/50"
              >
                Scan Again
              </Button>
              <Button 
                onClick={() => onNavigate('chatbot')}
                className="h-12 bg-gradient-to-r from-primary to-primary/90 hover:from-primary/90 hover:to-primary text-white glass-button"
              >
                Ask Expert
              </Button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}