import { useState } from 'react';
import { ArrowLeft, User, Settings, Globe, Bell, Shield, HelpCircle, Star, ChevronRight, LogOut } from 'lucide-react';
import { useAuth } from '../hooks/useAuth';
import { toast } from 'sonner@2.0.3';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Switch } from './ui/switch';
import { RadioGroup, RadioGroupItem } from './ui/radio-group';
import { Label } from './ui/label';
import { Separator } from './ui/separator';

interface ProfilePageProps {
  onNavigate: (screen: string) => void;
}

export function ProfilePage({ onNavigate }: ProfilePageProps) {
  const { user, profile, signOut, updateProfile } = useAuth();
  const [selectedLanguage, setSelectedLanguage] = useState(profile?.language || 'english');
  const [notifications, setNotifications] = useState(true);
  const [autoSync, setAutoSync] = useState(true);
  const [loading, setLoading] = useState(false);

  const languages = [
    { id: 'english', label: 'English', nativeLabel: 'English' },
    { id: 'hindi', label: 'Hindi', nativeLabel: 'हिन्दी' },
    { id: 'telugu', label: 'Telugu', nativeLabel: 'తెలుగు' }
  ];

  const settingsItems = [
    {
      id: 'notifications',
      title: 'Push Notifications',
      description: 'Get alerts about weather, crop recommendations',
      icon: Bell,
      type: 'switch',
      value: notifications,
      onChange: setNotifications
    },
    {
      id: 'sync',
      title: 'Auto-sync Data',
      description: 'Automatically sync farm data when online',
      icon: Settings,
      type: 'switch',
      value: autoSync,
      onChange: setAutoSync
    }
  ];

  const menuItems = [
    {
      id: 'help',
      title: 'Help & Support',
      description: 'FAQs, tutorials, and contact support',
      icon: HelpCircle
    },
    {
      id: 'privacy',
      title: 'Privacy & Security',
      description: 'Manage your data and privacy settings',
      icon: Shield
    },
    {
      id: 'feedback',
      title: 'Rate & Feedback',
      description: 'Share your experience with Krishi-Mitra AI',
      icon: Star
    }
  ];

  return (
    <div className="min-h-screen bg-background pb-20">
      {/* Header */}
      <div className="sticky top-0 bg-background/90 backdrop-blur-md border-b border-border z-10">
        <div className="flex items-center justify-between px-6 py-4">
          <div className="flex items-center gap-3">
            <Button 
              variant="ghost" 
              size="sm"
              onClick={() => onNavigate('home')}
              className="p-2"
            >
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <div>
              <h1 className="font-medium text-foreground">Profile & Settings</h1>
              <p className="text-xs text-muted-foreground">Manage your account and preferences</p>
            </div>
          </div>
        </div>
      </div>

      <div className="px-6 py-6 space-y-6">
        {/* Profile Card */}
        <Card className="glass-card border-0 organic-shadow">
          <CardContent className="p-6">
            <div className="flex items-center gap-4">
              <div className="w-16 h-16 rounded-full bg-gradient-to-br from-primary to-primary/80 flex items-center justify-center organic-shadow">
                <User className="w-8 h-8 text-white" />
              </div>
              <div className="flex-1">
                <h3 className="font-medium text-foreground text-lg">
                  {profile?.name || 'Welcome, Farmer!'}
                </h3>
                <p className="text-muted-foreground">{profile?.location || 'India'}</p>
                <p className="text-sm text-primary">{user?.email}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Language Settings */}
        <Card className="glass-card border-0 organic-shadow">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Globe className="w-5 h-5 text-primary" />
              Language Settings
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <p className="text-sm text-muted-foreground">
              Choose your preferred language for the app interface
            </p>
            
            <RadioGroup value={selectedLanguage} onValueChange={setSelectedLanguage}>
              {languages.map((language) => (
                <div key={language.id} className="flex items-center space-x-3 p-3 rounded-lg hover:bg-muted/20 transition-colors">
                  <RadioGroupItem 
                    value={language.id} 
                    id={language.id}
                    className="border-primary text-primary"
                  />
                  <Label htmlFor={language.id} className="flex-1 cursor-pointer">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="font-medium text-foreground">{language.label}</p>
                        <p className="text-lg text-muted-foreground">{language.nativeLabel}</p>
                      </div>
                    </div>
                  </Label>
                </div>
              ))}
            </RadioGroup>

            <Button 
              className="w-full h-12 cta-glow"
              style={{ backgroundColor: 'var(--cta)', color: 'var(--cta-foreground)' }}
              disabled={loading}
              onClick={async () => {
                setLoading(true);
                try {
                  await updateProfile({ language: selectedLanguage as any });
                  toast.success('Language preference updated!');
                } catch (error) {
                  toast.error('Failed to update language preference');
                } finally {
                  setLoading(false);
                }
              }}
            >
              {loading ? 'Updating...' : 'Apply Language Changes'}
            </Button>
          </CardContent>
        </Card>

        {/* App Settings */}
        <Card className="glass-card border-0 organic-shadow">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Settings className="w-5 h-5 text-primary" />
              App Settings
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {settingsItems.map((item, index) => (
              <div key={item.id}>
                <div className="flex items-center justify-between p-3 rounded-lg hover:bg-muted/20 transition-colors">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
                      <item.icon className="w-5 h-5 text-primary" />
                    </div>
                    <div>
                      <p className="font-medium text-foreground">{item.title}</p>
                      <p className="text-sm text-muted-foreground">{item.description}</p>
                    </div>
                  </div>
                  <Switch
                    checked={item.value as boolean}
                    onCheckedChange={item.onChange}
                    className="data-[state=checked]:bg-primary"
                  />
                </div>
                {index < settingsItems.length - 1 && <Separator className="my-2" />}
              </div>
            ))}
          </CardContent>
        </Card>

        {/* Other Menu Items */}
        <Card className="glass-card border-0 organic-shadow">
          <CardContent className="p-0">
            {menuItems.map((item, index) => (
              <div key={item.id}>
                <button 
                  className="w-full p-5 flex items-center gap-4 hover:bg-muted/20 transition-colors text-left"
                  onClick={() => {/* Handle navigation */}}
                >
                  <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
                    <item.icon className="w-5 h-5 text-primary" />
                  </div>
                  <div className="flex-1">
                    <p className="font-medium text-foreground">{item.title}</p>
                    <p className="text-sm text-muted-foreground">{item.description}</p>
                  </div>
                  <ChevronRight className="w-5 h-5 text-muted-foreground" />
                </button>
                {index < menuItems.length - 1 && <Separator />}
              </div>
            ))}
          </CardContent>
        </Card>

        {/* Sign Out Button */}
        <Card className="glass-card border-0 organic-shadow">
          <CardContent className="p-0">
            <button 
              className="w-full p-5 flex items-center gap-4 hover:bg-destructive/5 transition-colors text-left text-destructive"
              onClick={async () => {
                try {
                  await signOut();
                  toast.success('Signed out successfully');
                } catch (error) {
                  toast.error('Failed to sign out');
                }
              }}
            >
              <div className="w-10 h-10 rounded-lg bg-destructive/10 flex items-center justify-center">
                <LogOut className="w-5 h-5 text-destructive" />
              </div>
              <div className="flex-1">
                <p className="font-medium text-destructive">Sign Out</p>
                <p className="text-sm text-destructive/70">Sign out of your account</p>
              </div>
            </button>
          </CardContent>
        </Card>

        {/* App Info */}
        <div className="text-center space-y-2">
          <p className="text-sm text-muted-foreground">
            Krishi-Mitra AI v2.0.1
          </p>
          <p className="text-xs text-muted-foreground">
            Powered by Organic Tech • Made for Indian Farmers
          </p>
        </div>
      </div>
    </div>
  );
}