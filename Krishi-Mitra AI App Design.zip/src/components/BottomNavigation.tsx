import { Home, TrendingUp, User, MessageCircle } from 'lucide-react';

interface BottomNavigationProps {
  currentScreen: string;
  onNavigate: (screen: string) => void;
}

export function BottomNavigation({ currentScreen, onNavigate }: BottomNavigationProps) {
  const navItems = [
    { id: 'home', icon: Home, label: 'होम', englishLabel: 'Home' },
    { id: 'recommendations', icon: TrendingUp, label: 'सिफारिश', englishLabel: 'Recommendations' },
    { id: 'chatbot', icon: MessageCircle, label: 'सहायक', englishLabel: 'Assistant' },
    { id: 'profile', icon: User, label: 'प्रोफाइल', englishLabel: 'Profile' }
  ];

  return (
    <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-border px-4 py-2 safe-area-pb">
      <div className="flex items-center justify-around">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = currentScreen === item.id;
          
          return (
            <button
              key={item.id}
              onClick={() => onNavigate(item.id)}
              className={`flex flex-col items-center gap-1 p-2 rounded-lg transition-colors ${
                isActive 
                  ? 'text-accent bg-accent/10' 
                  : 'text-muted-foreground hover:text-foreground hover:bg-gray-50'
              }`}
            >
              <Icon className={`w-5 h-5 ${isActive ? 'text-accent' : ''}`} />
              <span className="text-xs">{item.label}</span>
            </button>
          );
        })}
      </div>
    </div>
  );
}