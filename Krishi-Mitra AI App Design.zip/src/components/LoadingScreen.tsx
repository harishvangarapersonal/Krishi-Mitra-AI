import { Sprout } from 'lucide-react';

export function LoadingScreen() {
  return (
    <div className="min-h-screen bg-background flex items-center justify-center">
      <div className="text-center">
        <div className="w-20 h-20 rounded-full bg-gradient-to-br from-primary to-primary/80 flex items-center justify-center mx-auto mb-6 organic-shadow animate-pulse">
          <Sprout className="w-10 h-10 text-white" />
        </div>
        <h2 className="text-xl font-medium text-foreground mb-2">
          Krishi-Mitra AI
        </h2>
        <p className="text-muted-foreground">
          Loading your farming toolkit...
        </p>
        <div className="flex justify-center mt-4">
          <div className="flex gap-1">
            <div className="w-2 h-2 bg-primary/60 rounded-full animate-bounce"></div>
            <div className="w-2 h-2 bg-primary/60 rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
            <div className="w-2 h-2 bg-primary/60 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
          </div>
        </div>
      </div>
    </div>
  );
}