
  # Krishi-Mitra AI App Design

  This is a code bundle for Krishi-Mitra AI App Design. The original project is available at https://www.figma.com/design/eqzQRqfZGfpdizTOuindkO/Krishi-Mitra-AI-App-Design.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  